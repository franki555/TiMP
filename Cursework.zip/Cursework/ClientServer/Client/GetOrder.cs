﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Client
{
    public static class GetOrder
    {
        public class OrderInfo
        {
            public int id;
            public string name;
            public int price;
            public int countProduct;
            public byte[] image;
            public string address_index;
            public string delivery_date;
        }

        public class BlockOrder
        {
            public PictureBox pictureBoxImage;
            public Label labelOrderDetails;
        }

        public static OrderInfo GetOrderInfo(
            SslTcpServer client, int id_user, string authKey, int id_order
            )
        {
            if (client.Client == null)
            {
                client = new SslTcpServer(ServerInformation.IpServer, ServerInformation.Port);
            }

            string request = $"/getOrder {id_user} {authKey} {id_order}";
            client.SendMessage(request);
            if (!(client.ReadMessage() is string response))
            {
                return null;
            }

            OrderInfo productInfo = new OrderInfo();

            if (response != "0" && response != "-1")
            {
                List<string> data = SplitString.split(response);
                productInfo.id = Convert.ToInt32(data[0]);
                string id_product = data[1].ToString();
                productInfo.name = data[2].Replace("|", " ");
                productInfo.price = Convert.ToInt32(data[3]);
                productInfo.countProduct = Convert.ToInt32(data[4]);
                productInfo.address_index = data[5];
                productInfo.delivery_date = data[6];

                request = $"/getImage {id_product}";
                client.SendMessage(request);
                response = client.ReadMessage();

                if (response != "0" && response != "-1")
                {
                    productInfo.image = Convert.FromBase64String(response);
                }
            }
            else
            {
                productInfo = null;
            }
            return productInfo;
        }

        public static BlockOrder GetOrderBlock(OrderInfo OrderInfo, int pos_product)
        {
            if (OrderInfo == null)
            {
                return null;
            }

            PictureBox pictureBox = new PictureBox();
            pictureBox.Location = new Point(ProductDisplayConfiguration.Cart.Image.StartPosX,
                ProductDisplayConfiguration.Cart.Image.StartPosY +
                pos_product * ProductDisplayConfiguration.Cart.vDelta);
            pictureBox.Width = ProductDisplayConfiguration.Cart.Image.SizeX;
            pictureBox.Height = ProductDisplayConfiguration.Cart.Image.SizeY;
            if (OrderInfo.image != null)
            {
                MemoryStream memoryStream = new MemoryStream(OrderInfo.image);
                pictureBox.Image = Image.FromStream(memoryStream);
            }
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.BorderStyle = BorderStyle.FixedSingle;
            pictureBox.BackColor = Color.White;

            Label label = new Label();
            label.Location = new Point(ProductDisplayConfiguration.Cart.ProductDetails.StartPosX,
                ProductDisplayConfiguration.Cart.ProductDetails.StartPosY +
                pos_product * ProductDisplayConfiguration.Cart.vDelta);
            label.Width = ProductDisplayConfiguration.Cart.ProductDetails.SizeX;
            label.Height = ProductDisplayConfiguration.Cart.ProductDetails.SizeY;
            label.MaximumSize = new Size(ProductDisplayConfiguration.Cart.ProductDetails.SizeX,
                ProductDisplayConfiguration.Cart.ProductDetails.SizeY);
            label.Font = new Font("Segoe UI Black", 10F,
                (FontStyle.Bold | FontStyle.Italic), GraphicsUnit.Point);
            label.ForeColor = Color.White;
            label.Text = $"Заказ №{OrderInfo.id}\n" +
                $"{OrderInfo.name}\n" +
                $"Сумма заказа: {OrderInfo.price}\n" +
                $"Колличество товара: {OrderInfo.countProduct}\n" +
                $"Дата доставки: {OrderInfo.delivery_date}\n" +
                $"Индекс почтового отделения: {OrderInfo.address_index}";

            BlockOrder blockProduct = new BlockOrder();
            blockProduct.pictureBoxImage = pictureBox;
            blockProduct.labelOrderDetails = label;

            return blockProduct;
        }
    }
}