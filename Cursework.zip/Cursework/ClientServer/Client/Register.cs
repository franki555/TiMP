﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Client
{
    public partial class Register : Form
    {
        /// <summary>
        /// Variables
        /// </summary>

        private Login login = null;

        /// <summary>
        /// Methods related to the form
        /// </summary>

        public Register(Login __login)
        {
            InitializeComponent();

            login = __login;

            labelLogin.BackColor = Color.Transparent;
            labelLogin.Font = new Font(labelLogin.Font, labelLogin.Font.Style | FontStyle.Bold);

            labelPassword.BackColor = Color.Transparent;
            labelPassword.Font = new Font(labelLogin.Font, labelLogin.Font.Style | FontStyle.Bold);
            textBoxPassword.UseSystemPasswordChar = true;

            labelConfirm.BackColor = Color.Transparent;
            labelConfirm.Font = new Font(labelLogin.Font, labelLogin.Font.Style | FontStyle.Bold);
            textBoxConfirm.UseSystemPasswordChar = true;

            labelUsername.BackColor = Color.Transparent;
            labelUsername.Font = new Font(labelLogin.Font, labelLogin.Font.Style | FontStyle.Bold);

            labelTg.BackColor = Color.Transparent;
            labelTg.Font = new Font(labelLogin.Font, labelLogin.Font.Style | FontStyle.Bold);
        }

        private void buttonRegister_Click(object sender, EventArgs e)
        {
            _Register();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            Cancel();
        }

        private void Register_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void textBoxLogin_KeyPress(object sender, KeyPressEventArgs e)
        {
            PressEnter(e);
        }

        private void textBoxUsername_KeyPress(object sender, KeyPressEventArgs e)
        {
            PressEnter(e);
        }

        private void textBoxTg_KeyPress(object sender, KeyPressEventArgs e)
        {
            PressEnter(e);
        }

        private void textBoxPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            PressEnter(e);
        }

        private void textBoxConfirm_KeyPress(object sender, KeyPressEventArgs e)
        {
            PressEnter(e);
        }

        /// <summary>
        /// Others methods
        /// </summary>

        private void _Register()
        {
            string login = textBoxLogin.Text.ToString();
            string password = textBoxPassword.Text.ToString();
            string confirm = textBoxConfirm.Text.ToString();
            string username = textBoxUsername.Text.ToString();
            string mail = textBoxTg.Text.ToString();

            if ((login.IndexOf(' ') > -1) || (password.IndexOf(' ') > -1) ||
                (confirm.IndexOf(' ') > -1) || (username.IndexOf(' ') > -1) ||
                (mail.IndexOf(' ') > -1))
            {
                MessageBox.Show("Поля не должны содержать пробелы!");
            }
            else if ((!string.IsNullOrEmpty(login) && !string.IsNullOrWhiteSpace(login))
                && (!string.IsNullOrEmpty(password) && !string.IsNullOrWhiteSpace(password))
                && (!string.IsNullOrEmpty(confirm) && !string.IsNullOrWhiteSpace(confirm))
                && (!string.IsNullOrEmpty(username) && !string.IsNullOrWhiteSpace(username))
                && (!string.IsNullOrEmpty(mail) && !string.IsNullOrWhiteSpace(mail)))
            {
                if (password != confirm)
                    MessageBox.Show("Пароли не совпадают!");
                else
                {
                    SslTcpServer client = new SslTcpServer(
                        ServerInformation.IpServer, ServerInformation.Port
                        );

                    if (client.Client == null)
                    {
                        MessageBox.Show("Не удалось соеденится с сервером");
                        Application.Exit();
                    }

                    string request = $"/register {login} {password} {confirm} {username} {mail}";
                    client.SendMessage(request);
                    string response = client.ReadMessage();
                    client.SendMessage("<END>");
                    client.Close();

                    if (response == "0")
                    {
                        MessageBox.Show("Логин, имя пользователя или почта уже заняты!");
                    }
                    else if (response == "-1")
                    {
                        MessageBox.Show("Обнаружена SQL Injection!");
                    }
                    else if (response == "-5")
                    {
                        MessageBox.Show("Введите значение от 6 до 16");
                    }
                    else
                    {
                        MessageBox.Show("Регистрация прошла успешно!");
                        Cancel();
                    }
                }
            }
            else
            {
                MessageBox.Show("Все поля должны быть заполены!");
            }
        }

        private void PressEnter(KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                buttonRegister.PerformClick();
            }
        }

        private void Cancel()
        {
            Hide();
            if (login != null)
            {
                login.Show();
            }
        }
    }
}