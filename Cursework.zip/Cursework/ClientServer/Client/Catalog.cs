﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client
{
    public partial class Catalog : Form
    {
        /// <summary>
        /// Variables
        /// </summary>

        public Login login = null;
        List<GetCatalog.ProductInfo> products = null;
        int minPrice = 0;
        int maxPrice = 0;
        public int id_user;
        public string authKey;
        public int bal;

        /// <summary>
        /// Methods related to the form
        /// </summary>

        public Catalog(int __id_user, string __authKey, int __bal)
        {
            InitializeComponent();

            id_user = __id_user;
            authKey = __authKey;
            bal = __bal;

            labelBal.Text = $"Ваш баланс:\n{Bal}руб.";
        }

        private void Catalog_FormClosed(object sender, FormClosedEventArgs e)
        {
            Id_user = 0;
            AuthKey = "";
            Bal = 0;
            Application.Exit();
        }

        private void Catalog_Load(object sender, EventArgs e)
        {
            timerLastUserInput.Start();
            timerUpdateAuthKey.Start();
            FillProductsWithPanel();
        }

        private void buttonAddToCart_Click(object sender, EventArgs e)
        {
            AddToCart(sender);
        }

        private void buttonAddToCart_MouseEnterButton(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseEnterButton(sender);
        }

        private void buttonAddToCart_MouseLeaveButton(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseLeaveButton(sender);
        }

        private void buttonAddBal_MouseEnter(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseEnterButton(sender);
        }

        private void buttonAddBal_MouseLeave(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseLeaveButton(sender);
        }

        private void buttonSearch_MouseEnter(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseEnterButton(sender);
        }

        private void buttonSearch_MouseLeave(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseLeaveButton(sender);
        }

        private void buttonUpdate_MouseEnter(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseEnterButton(sender);
        }

        private void buttonUpdate_MouseLeave(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseLeaveButton(sender);
        }

        private void buttonCart_MouseEnter(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseEnterButton(sender);
        }

        private void buttonCart_MouseLeave(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseLeaveButton(sender);
        }

        private void buttonOrder_MouseEnter(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseEnterButton(sender);
        }

        private void buttonOrder_MouseLeave(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseLeaveButton(sender);
        }

        private void buttonChangePassword_MouseEnter(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseEnterButton(sender);
        }

        private void buttonChangePassword_MouseLeave(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseLeaveButton(sender);
        }

        private void buttonExit_MouseEnter(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseEnterButton(sender);
        }

        private void buttonExit_MouseLeave(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseLeaveButton(sender);
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            Search();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Exit();
        }

        private void buttonChangePassword_Click(object sender, EventArgs e)
        {
            ChangePassword changePassword = new ChangePassword(this);
            changePassword.Show();
        }

        private void buttonAddBal_Click(object sender, EventArgs e)
        {
            AddBalance addBalance = new AddBalance(this);
            addBalance.Show();
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            UpdateCatalog();
        }

        private void buttonCart_Click(object sender, EventArgs e)
        {
            Cart cart = new Cart(this);
            cart.Show();
        }

        private void buttonOrder_Click(object sender, EventArgs e)
        {
            Order order = new Order(this);
            order.Show();
        }

        private void timerLastUserInput_Tick(object sender, EventArgs e)
        {
            ExitIfInactive();
        }

        private void timerUpdateAuthKey_Tick(object sender, EventArgs e)
        {
            UpdateAuthKey();
        }

        /// <summary>
        /// Others methods
        /// </summary>

        public int Id_user { get { return id_user; } set { id_user = value; } }
        public string AuthKey { get { return authKey; } set { authKey = value; } }
        public int Bal { get { return bal; } set { bal = value; } }
        public Login Login { get { return login; } set { login = value; } }
        public Label LabelBal { get { return labelBal; } set { labelBal = value; } }

        private async void FillProductsWithPanel()
        {
            SslTcpServer client = new SslTcpServer(
                ServerInformation.IpServer, ServerInformation.Port
                );

            if (client.Client == null)
            {
                Id_user = 0;
                AuthKey = "";
                Bal = 0;
                MessageBox.Show("Не удалось соеденится с сервером");
                Application.Exit();
            }

            List<GetCatalog.ProductInfo> __products = new List<GetCatalog.ProductInfo>();

            int id_prod = 0;
            int pos_product = 0;
            while (true)
            {
                if (await Task.Run(() => GetCatalog.GetProductInfo(client, id_prod)) is
                    GetCatalog.ProductInfo product)
                {
                    if (await Task.Run(() => GetCatalog.GetProductBlock(product, pos_product)) is
                    GetCatalog.BlockProduct blockProduct)
                    {
                        blockProduct.buttonAddCart.Click += buttonAddToCart_Click;
                        blockProduct.buttonAddCart.MouseEnter += buttonAddToCart_MouseEnterButton;
                        blockProduct.buttonAddCart.MouseLeave += buttonAddToCart_MouseLeaveButton;

                        SuspendLayout();
                        panelCatalog.Controls.Add(blockProduct.pictureBoxImage);
                        panelCatalog.Controls.Add(blockProduct.labelProductDetails);
                        panelCatalog.Controls.Add(blockProduct.buttonAddCart);
                        ResumeLayout();

                        if (product.price < minPrice)
                            minPrice = product.price;
                        if (product.price > maxPrice)
                            maxPrice = product.price;

                        __products.Add(product);

                        id_prod = product.id;
                    }
                }
                else
                    break;
                pos_product++;
            }

            client.SendMessage("<END>");
            client.Close();

            if (panelCatalog.Controls.Count == 0)
            {
                MessageBox.Show("В настоящее время каталог товаров пуст. Загляните позже");
            }
            textBoxOt.Text = minPrice.ToString();
            textBoxDo.Text = maxPrice.ToString();
            products = __products;
        }

        private void Search()
        {
            string name = textBoxName.Text.ToString().ToLower().Replace(" ", "");
            int __minPrice = minPrice;
            int __maxPrice = maxPrice;

            try
            {
                if (!string.IsNullOrEmpty(textBoxOt.Text) && !string.IsNullOrWhiteSpace(textBoxOt.Text))
                {
                    __minPrice = Convert.ToInt32(textBoxOt.Text);
                }
                else
                {
                    textBoxOt.Text = __minPrice.ToString();
                }
                if (!string.IsNullOrEmpty(textBoxDo.Text) && !string.IsNullOrWhiteSpace(textBoxDo.Text))
                {
                    __maxPrice = Convert.ToInt32(textBoxDo.Text);
                }
                else
                {
                    textBoxDo.Text = __maxPrice.ToString();
                }
            }
            catch
            {
                MessageBox.Show("Значения должны быть числовыми!");
                return;
            }

            if (products != null)
            {
                ClearPanel.Сlear(panelCatalog);

                int posProduct = 0;
                for (int i = 0; i < products.Count; i++)
                {
                    if (((products[i].name.ToLower().Replace(" ", "").IndexOf(name) > -1) ||
                        (string.IsNullOrEmpty(name) ||
                        string.IsNullOrWhiteSpace(name))) &&
                        (products[i].price >= __minPrice) && (products[i].price <= __maxPrice))
                    {
                        if (GetCatalog.GetProductBlock(products[i], posProduct) is
                            GetCatalog.BlockProduct blockProduct)
                        {
                            blockProduct.buttonAddCart.Click += buttonAddToCart_Click;
                            blockProduct.buttonAddCart.MouseEnter += buttonAddToCart_MouseEnterButton;
                            blockProduct.buttonAddCart.MouseLeave += buttonAddToCart_MouseLeaveButton;

                            SuspendLayout();
                            panelCatalog.Controls.Add(blockProduct.pictureBoxImage);
                            panelCatalog.Controls.Add(blockProduct.labelProductDetails);
                            panelCatalog.Controls.Add(blockProduct.buttonAddCart);
                            ResumeLayout();

                            posProduct++;
                        }
                    }
                }
            }
        }

        private void AddToCart(object sender)
        {
            var button = (Button)sender;

            if (button == null)
            {
                MessageBox.Show("Ошибка, попробуйте снова");
                return;
            }

            int id_prod = Convert.ToInt32(button.Tag);

            SslTcpServer client = new SslTcpServer(
                ServerInformation.IpServer, ServerInformation.Port
                );

            if (client.Client == null)
            {
                Id_user = 0;
                AuthKey = "";
                Bal = 0;
                MessageBox.Show("Не удалось соеденится с сервером");
                Application.Exit();
            }

            if (client.Client == null)
            {
                Id_user = 0;
                AuthKey = "";
                Bal = 0;
                Application.Exit();
            }

            string request = $"/addCart {Id_user} {AuthKey} {id_prod}";
            client.SendMessage(request);
            string response = client.ReadMessage();
            client.SendMessage("<END>");
            client.Close();

            if (response == "0" && response == "-1")
            {
                MessageBox.Show("Продукт не был добавлен в корзину!");
            }
            else if (response == "-2")
            {
                MessageBox.Show("Продукт уже был добавлен в корзину ранее!");
            }
            else
            {
                MessageBox.Show("Продукт успешно добавлен в корзину!");
            }
        }

        private void UpdateCatalog()
        {
            labelBal.Text = $"Ваш баланс:\n{Bal}руб.";
            textBoxOt.Text = minPrice.ToString();
            textBoxDo.Text = maxPrice.ToString();
            ClearPanel.Сlear(panelCatalog);
            FillProductsWithPanel();
        }

        private void UpdateAuthKey()
        {
            SslTcpServer client = new SslTcpServer(
                ServerInformation.IpServer, ServerInformation.Port
                );

            if (client.Client == null)
            {
                Id_user = 0;
                AuthKey = "";
                Bal = 0;
                MessageBox.Show("Не удалось соеденится с сервером");
                Application.Exit();
            }

            string request = $"/getAuthKey {Id_user} {AuthKey}";
            client.SendMessage(request);
            string response = client.ReadMessage();
            client.SendMessage("<END>");
            client.Close();

            if (response == "0" || response == "-1")
            {
                Id_user = 0;
                AuthKey = "";
                Bal = 0;

                MessageBox.Show("Ошибка аутентификации. Попробуйте перезайти!");

                if (Login != null)
                {
                    Hide();
                    Login.Show();
                }
                else
                {
                    Application.Exit();
                }
            }
            else
            {
                AuthKey = response;
            }
        }

        private void ExitIfInactive()
        {
            if (LastInputInfo.GetIdleTime() > 900000)
            {
                Id_user = 0;
                AuthKey = "";
                Bal = 0;
                if (Login != null)
                {
                    Hide();
                    Login.Show();
                }
                else
                    Application.Exit();
            }
        }

        private void Exit()
        {
            Id_user = 0;
            AuthKey = "";
            Bal = 0;
            if (Login != null)
            {
                Hide();
                Login.Show();
            }
            else
                Application.Exit();
        }

    }
}