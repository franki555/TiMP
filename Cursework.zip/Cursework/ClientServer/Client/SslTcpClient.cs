﻿using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Windows.Forms;

namespace Client
{
    public class SslTcpServer
    {
        private TcpClient client = null;
        public TcpClient Client { get { return client; } }
        private SslStream sslStream = null;

        public SslTcpServer(string ipServer, int port)
        {
            try
            {
                client = new TcpClient(ipServer, port);
            }
            catch
            {
                MessageBox.Show("Сервер временно не доступен, повторите попытку позже!");
                return;
            }

            sslStream = new SslStream(
                client.GetStream(),
                false,
                new RemoteCertificateValidationCallback(CertificateValidationCallback));

            try
            {
                sslStream.AuthenticateAsClient("clientName");
            }
            catch (AuthenticationException e)
            {
                MessageBox.Show($"Exception: {e.Message}") ;

                if (e.InnerException != null)
                {
                    MessageBox.Show($"Inner exception: {e.InnerException.Message}");
                }

                MessageBox.Show("Authentication failed - closing the connection.");

                client.Close();
                return;
            }
        }

        public void SendMessage(string message)
        {
            try
            {
                sslStream.Write(Encoding.UTF8.GetBytes(message + "<EOF>"));
                sslStream.Flush();
            }
            catch
            {
                MessageBox.Show("Сервер разорвал соединение");

                client.Close();
                return;
            }
        }

        public string ReadMessage()
        {
            byte[] buffer = null;
            try
            {
                buffer = new byte[client.ReceiveBufferSize];
            }
            catch
            {
                return null;
            }

            StringBuilder messageData = new StringBuilder();

            int bytesRead = -1;
            try
            {
                do
                {
                    bytesRead = sslStream.Read(buffer, 0, client.ReceiveBufferSize);
                    Decoder decoder = Encoding.UTF8.GetDecoder();
                    char[] chars = new char[decoder.GetCharCount(buffer, 0, bytesRead)];
                    decoder.GetChars(buffer, 0, bytesRead, chars, 0);
                    messageData.Append(chars);

                    if (messageData.ToString().IndexOf("<EOF>") != -1)
                    {
                        break;
                    }
                } while (bytesRead != 0);

                return messageData.ToString().Substring(0, messageData.Length - 5);
            }
            catch
            {
                MessageBox.Show("Превышено время ожидания");

                client.Close();
                return "0";
            }
        }

        public void Close()
        {
            client.Close();
        }

        static bool CertificateValidationCallback(
            object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
    }
}