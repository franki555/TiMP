﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client
{
    public partial class Cart : Form
    {
        /// <summary>
        /// Variables
        /// </summary>

        private Catalog catalog = null;
        private List<GetCart.ProductInfo> products = null;
        private List<GetCart.BlockProduct> productsBlock = null;

        /// <summary>
        /// Methods related to the form
        /// </summary>

        public Cart(Catalog main)
        {
            InitializeComponent();

            catalog = main;
        }

        private void Cart_FormClosed(object sender, FormClosedEventArgs e)
        {
            Hide();
        }

        private void Cart_Load(object sender, EventArgs e)
        {
            FillProductsWithPanel();
        }

        private void buttonDeleteProduct_Click(object sender, EventArgs e)
        {
            DeleteProduct(sender);
        }

        private void buttonDeleteProduct_MouseEnter(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseEnterButton(sender);
        }

        private void buttonDeleteProduct_MouseLeave(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseLeaveButton(sender);
        }

        private void buttonBuy_Click(object sender, EventArgs e)
        {
            BuyProduct(sender);
        }

        private void buttonBuy_MouseEnter(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseEnterButton(sender);
        }

        private void buttonBuy_MouseLeave(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseLeaveButton(sender);
        }

        private void buttonExit_MouseEnter(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseEnterButton(sender);
        }

        private void buttonExit_MouseLeave(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseLeaveButton(sender);
        }

        private void numericUpDownCount_ValueChanged(object sender, EventArgs e)
        {
            Count_ValueChanged(sender);
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Hide();
        }

        /// <summary>
        /// Others methods
        /// </summary>

        private void BuyProduct(object sender)
        {
            var button = (Button)sender;

            if (button == null)
            {
                MessageBox.Show("Ошибка, попробуйте снова");
                return;
            }

            int id_prod = Convert.ToInt32(button.Tag);
            int indexListProducts = GetIndexListProductsFromIdProduct(id_prod);
            int count =
                Convert.ToInt32(productsBlock[indexListProducts].numericUpDownCount.Value);

            if(count <= 0)
            {
                MessageBox.Show("Введите значение больше 0!");
                return;
            }    

            BuyProducConfirm buyProductConfirm =
                new BuyProducConfirm(catalog, this, catalog.Id_user, catalog.AuthKey, id_prod, count);

            buyProductConfirm.Show();
        }

        private void DeleteProduct(object sender)
        {
            var button = (Button)sender;

            if (button == null)
            {
                MessageBox.Show("Ошибка, попробуйте снова");
                return;
            }

            int id_prod = Convert.ToInt32(button.Tag);

            SslTcpServer client = new SslTcpServer(
                ServerInformation.IpServer, ServerInformation.Port
                );

            if (client.Client == null)
            {
                catalog.Id_user = 0;
                catalog.AuthKey = "";
                catalog.Bal = 0;
                MessageBox.Show("Не удалось соеденится с сервером");
                Application.Exit();
            }

            string request = $"/delCart {catalog.Id_user} {catalog.AuthKey} {id_prod}";
            client.SendMessage(request);
            string response = client.ReadMessage();
            client.SendMessage("<END>");
            client.Close();

            if (response != "1")
            {
                MessageBox.Show("Продукт не был удален из корзины!\nПопробуйте снова!");
                return;
            }

            ClearPanel.Сlear(panelCart);
            FillProductsWithPanel();
        }

        private void Count_ValueChanged(object sender)
        {
            NumericUpDown numUpDown = (NumericUpDown)sender;

            if (numUpDown == null)
            {
                MessageBox.Show("Ошибка, попробуйте снова");
                return;
            }

            int id_prod = Convert.ToInt32(numUpDown.Tag);
            int indexListProducts = GetIndexListProductsFromIdProduct(id_prod);

            if (indexListProducts == -1)
            {
                return;
            }

            int count = Convert.ToInt32(numUpDown.Value);

            productsBlock[indexListProducts].labelProductDetails.Text =
                $"{products[indexListProducts].name}\n" +
                $"Цена: {products[indexListProducts].price * count}р за {count} шт.\n" +
                $"В наличии: {products[indexListProducts].countProduct}"; ;
        }

        private async void FillProductsWithPanel()
        {
            SslTcpServer client = new SslTcpServer(
                ServerInformation.IpServer, ServerInformation.Port
                );

            if (client.Client == null)
            {
                catalog.Id_user = 0;
                catalog.AuthKey = "";
                catalog.Bal = 0;
                MessageBox.Show("Не удалось соеденится с сервером");
                Application.Exit();
            }

            List<GetCart.ProductInfo> __products = new List<GetCart.ProductInfo>();
            List<GetCart.BlockProduct> __productsBlock = new List<GetCart.BlockProduct>();

            int id_prod = 0;
            int pos_product = 0;
            while (true)
            {
                if (await Task.Run(() => GetCart.GetProductInfo
                (client, catalog.Id_user, catalog.AuthKey, id_prod)) is
                    GetCart.ProductInfo product)
                {
                    if (await Task.Run(() => GetCart.GetProductBlock(product, pos_product)) is
                    GetCart.BlockProduct blockProduct)
                    {
                        blockProduct.buttonDeleteProduct.Click += buttonDeleteProduct_Click;
                        blockProduct.buttonDeleteProduct.MouseEnter += buttonDeleteProduct_MouseEnter;
                        blockProduct.buttonDeleteProduct.MouseLeave += buttonDeleteProduct_MouseLeave;
                        blockProduct.buttonBuy.Click += buttonBuy_Click;
                        blockProduct.buttonBuy.MouseEnter += buttonBuy_MouseEnter;
                        blockProduct.buttonBuy.MouseLeave += buttonBuy_MouseLeave;
                        blockProduct.numericUpDownCount.ValueChanged += numericUpDownCount_ValueChanged;

                        SuspendLayout();
                        panelCart.Controls.Add(blockProduct.pictureBoxImage);
                        panelCart.Controls.Add(blockProduct.labelProductDetails);
                        panelCart.Controls.Add(blockProduct.numericUpDownCount);
                        panelCart.Controls.Add(blockProduct.buttonBuy);
                        panelCart.Controls.Add(blockProduct.buttonDeleteProduct);
                        ResumeLayout();

                        __products.Add(product);
                        __productsBlock.Add(blockProduct);

                        id_prod = product.id;
                    }
                }
                else
                {
                    break;
                }

                pos_product++;
            }

            client.SendMessage("<END>");
            client.Close();

            if (panelCart.Controls.Count == 0)
            {
                MessageBox.Show("Ваша корзина пуста!");
            }

            products = __products;
            productsBlock = __productsBlock;
        }

        private int GetIndexListProductsFromIdProduct(int id_prod)
        {
            for (int i = 0; i < products.Count; i++)
            {
                if (products[i].id == id_prod)
                {
                    return i;
                }
            }
            return -1;
        }

        public void CartUpdate()
        {
            ClearPanel.Сlear(panelCart);
            FillProductsWithPanel();
        }

    }
}