﻿
using System.Drawing;
using System.Windows.Forms;

namespace Client
{
    /// <summary>
    /// Модуль для изменении цвета кнопки при наведении на нее курсора
    /// </summary>

    static public class MouseEnterAndLeaveButton
    {
        // Когда наводим курсор на кнопку
        static public void MouseEnterButton(object sender)
        {
            var button = (Button)sender;

            if (button == null)
            {
                MessageBox.Show("Ошибка, попробуйте снова");
                return;
            }

            button.BackColor = Color.Green;
        }

        // Когда уводим курсор с кнопки
        static public void MouseLeaveButton(object sender)
        {
            var button = (Button)sender;

            if (button == null)
            {
                MessageBox.Show("Ошибка, попробуйте снова");
                return;
            }

            button.BackColor = Color.Indigo;
        }
    }
}
