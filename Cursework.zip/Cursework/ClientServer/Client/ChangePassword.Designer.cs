﻿
namespace Client
{
    partial class ChangePassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonCancel = new System.Windows.Forms.Button();
            this.buttonChange = new System.Windows.Forms.Button();
            this.textBoxNewPsw = new System.Windows.Forms.TextBox();
            this.labelNewPsw = new System.Windows.Forms.Label();
            this.textBoxConfirm = new System.Windows.Forms.TextBox();
            this.labelConfirm = new System.Windows.Forms.Label();
            this.textBoxOldPsw = new System.Windows.Forms.TextBox();
            this.labelOldPsw = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonCancel
            // 
            this.buttonCancel.BackColor = System.Drawing.Color.Indigo;
            this.buttonCancel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.buttonCancel.FlatAppearance.BorderSize = 0;
            this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCancel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonCancel.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonCancel.Location = new System.Drawing.Point(0, 315);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(284, 46);
            this.buttonCancel.TabIndex = 5;
            this.buttonCancel.Text = "Отмена";
            this.buttonCancel.UseVisualStyleBackColor = false;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            this.buttonCancel.MouseEnter += new System.EventHandler(this.buttonCancel_MouseEnter);
            this.buttonCancel.MouseLeave += new System.EventHandler(this.buttonCancel_MouseLeave);
            // 
            // buttonChange
            // 
            this.buttonChange.BackColor = System.Drawing.Color.Indigo;
            this.buttonChange.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.buttonChange.FlatAppearance.BorderSize = 0;
            this.buttonChange.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonChange.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonChange.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonChange.Location = new System.Drawing.Point(0, 269);
            this.buttonChange.Name = "buttonChange";
            this.buttonChange.Size = new System.Drawing.Size(284, 46);
            this.buttonChange.TabIndex = 4;
            this.buttonChange.Text = "Сменить пароль";
            this.buttonChange.UseVisualStyleBackColor = false;
            this.buttonChange.Click += new System.EventHandler(this.buttonChange_Click);
            this.buttonChange.MouseEnter += new System.EventHandler(this.buttonChange_MouseEnter);
            this.buttonChange.MouseLeave += new System.EventHandler(this.buttonChange_MouseLeave);
            // 
            // textBoxNewPsw
            // 
            this.textBoxNewPsw.Dock = System.Windows.Forms.DockStyle.Top;
            this.textBoxNewPsw.Location = new System.Drawing.Point(0, 107);
            this.textBoxNewPsw.Name = "textBoxNewPsw";
            this.textBoxNewPsw.Size = new System.Drawing.Size(284, 23);
            this.textBoxNewPsw.TabIndex = 2;
            this.textBoxNewPsw.UseSystemPasswordChar = true;
            this.textBoxNewPsw.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxNewPsw_KeyPress);
            // 
            // labelNewPsw
            // 
            this.labelNewPsw.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelNewPsw.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelNewPsw.ForeColor = System.Drawing.SystemColors.Control;
            this.labelNewPsw.Location = new System.Drawing.Point(0, 69);
            this.labelNewPsw.Name = "labelNewPsw";
            this.labelNewPsw.Size = new System.Drawing.Size(284, 38);
            this.labelNewPsw.TabIndex = 3;
            this.labelNewPsw.Text = "Новый пароль";
            this.labelNewPsw.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // textBoxConfirm
            // 
            this.textBoxConfirm.Dock = System.Windows.Forms.DockStyle.Top;
            this.textBoxConfirm.Location = new System.Drawing.Point(0, 168);
            this.textBoxConfirm.Name = "textBoxConfirm";
            this.textBoxConfirm.Size = new System.Drawing.Size(284, 23);
            this.textBoxConfirm.TabIndex = 3;
            this.textBoxConfirm.UseSystemPasswordChar = true;
            this.textBoxConfirm.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxConfirm_KeyPress);
            // 
            // labelConfirm
            // 
            this.labelConfirm.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelConfirm.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelConfirm.ForeColor = System.Drawing.SystemColors.Control;
            this.labelConfirm.Location = new System.Drawing.Point(0, 130);
            this.labelConfirm.Name = "labelConfirm";
            this.labelConfirm.Size = new System.Drawing.Size(284, 38);
            this.labelConfirm.TabIndex = 5;
            this.labelConfirm.Text = "Подтвердите новый пароль";
            this.labelConfirm.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // textBoxOldPsw
            // 
            this.textBoxOldPsw.BackColor = System.Drawing.SystemColors.Window;
            this.textBoxOldPsw.Dock = System.Windows.Forms.DockStyle.Top;
            this.textBoxOldPsw.Location = new System.Drawing.Point(0, 46);
            this.textBoxOldPsw.Name = "textBoxOldPsw";
            this.textBoxOldPsw.Size = new System.Drawing.Size(284, 23);
            this.textBoxOldPsw.TabIndex = 1;
            this.textBoxOldPsw.UseSystemPasswordChar = true;
            this.textBoxOldPsw.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxOldPsw_KeyPress);
            // 
            // labelOldPsw
            // 
            this.labelOldPsw.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelOldPsw.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelOldPsw.ForeColor = System.Drawing.SystemColors.Control;
            this.labelOldPsw.Location = new System.Drawing.Point(0, 0);
            this.labelOldPsw.Name = "labelOldPsw";
            this.labelOldPsw.Size = new System.Drawing.Size(284, 46);
            this.labelOldPsw.TabIndex = 7;
            this.labelOldPsw.Text = "Старый пароль";
            this.labelOldPsw.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // ChangePassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumPurple;
            this.ClientSize = new System.Drawing.Size(284, 361);
            this.Controls.Add(this.textBoxConfirm);
            this.Controls.Add(this.labelConfirm);
            this.Controls.Add(this.buttonChange);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.textBoxNewPsw);
            this.Controls.Add(this.labelNewPsw);
            this.Controls.Add(this.textBoxOldPsw);
            this.Controls.Add(this.labelOldPsw);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "ChangePassword";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Смена Пароля";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ChangePassword_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Button buttonChange;
        private System.Windows.Forms.TextBox textBoxNewPsw;
        private System.Windows.Forms.Label labelNewPsw;
        private System.Windows.Forms.TextBox textBoxConfirm;
        private System.Windows.Forms.Label labelConfirm;
        private System.Windows.Forms.TextBox textBoxOldPsw;
        private System.Windows.Forms.Label labelOldPsw;
    }
}