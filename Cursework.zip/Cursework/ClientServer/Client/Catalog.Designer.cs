﻿
namespace Client
{
    partial class Catalog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonChangePassword = new System.Windows.Forms.Button();
            this.buttonCart = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonOrder = new System.Windows.Forms.Button();
            this.panelCatalog = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.buttonSearch = new System.Windows.Forms.Button();
            this.textBoxDo = new System.Windows.Forms.TextBox();
            this.labelDo = new System.Windows.Forms.Label();
            this.textBoxOt = new System.Windows.Forms.TextBox();
            this.labelOt = new System.Windows.Forms.Label();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.labelName = new System.Windows.Forms.Label();
            this.labelSearch = new System.Windows.Forms.Label();
            this.buttonAddBal = new System.Windows.Forms.Button();
            this.labelBal = new System.Windows.Forms.Label();
            this.timerLastUserInput = new System.Windows.Forms.Timer(this.components);
            this.timerUpdateAuthKey = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.Indigo;
            this.buttonExit.Dock = System.Windows.Forms.DockStyle.Right;
            this.buttonExit.FlatAppearance.BorderSize = 0;
            this.buttonExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonExit.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonExit.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonExit.Location = new System.Drawing.Point(634, 0);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(200, 38);
            this.buttonExit.TabIndex = 10;
            this.buttonExit.Text = "Выйти";
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            this.buttonExit.MouseEnter += new System.EventHandler(this.buttonExit_MouseEnter);
            this.buttonExit.MouseLeave += new System.EventHandler(this.buttonExit_MouseLeave);
            // 
            // buttonChangePassword
            // 
            this.buttonChangePassword.BackColor = System.Drawing.Color.Indigo;
            this.buttonChangePassword.Dock = System.Windows.Forms.DockStyle.Right;
            this.buttonChangePassword.FlatAppearance.BorderSize = 0;
            this.buttonChangePassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonChangePassword.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonChangePassword.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonChangePassword.Location = new System.Drawing.Point(434, 0);
            this.buttonChangePassword.Name = "buttonChangePassword";
            this.buttonChangePassword.Size = new System.Drawing.Size(200, 38);
            this.buttonChangePassword.TabIndex = 9;
            this.buttonChangePassword.Text = "Сменить пароль";
            this.buttonChangePassword.UseVisualStyleBackColor = false;
            this.buttonChangePassword.Click += new System.EventHandler(this.buttonChangePassword_Click);
            this.buttonChangePassword.MouseEnter += new System.EventHandler(this.buttonChangePassword_MouseEnter);
            this.buttonChangePassword.MouseLeave += new System.EventHandler(this.buttonChangePassword_MouseLeave);
            // 
            // buttonCart
            // 
            this.buttonCart.BackColor = System.Drawing.Color.Indigo;
            this.buttonCart.Dock = System.Windows.Forms.DockStyle.Left;
            this.buttonCart.FlatAppearance.BorderSize = 0;
            this.buttonCart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCart.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonCart.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonCart.Location = new System.Drawing.Point(0, 0);
            this.buttonCart.Name = "buttonCart";
            this.buttonCart.Size = new System.Drawing.Size(200, 38);
            this.buttonCart.TabIndex = 7;
            this.buttonCart.Text = "Корзина";
            this.buttonCart.UseVisualStyleBackColor = false;
            this.buttonCart.Click += new System.EventHandler(this.buttonCart_Click);
            this.buttonCart.MouseEnter += new System.EventHandler(this.buttonCart_MouseEnter);
            this.buttonCart.MouseLeave += new System.EventHandler(this.buttonCart_MouseLeave);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.BlueViolet;
            this.panel1.Controls.Add(this.buttonOrder);
            this.panel1.Controls.Add(this.buttonChangePassword);
            this.panel1.Controls.Add(this.buttonExit);
            this.panel1.Controls.Add(this.buttonCart);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 423);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(834, 38);
            this.panel1.TabIndex = 0;
            // 
            // buttonOrder
            // 
            this.buttonOrder.BackColor = System.Drawing.Color.Indigo;
            this.buttonOrder.Dock = System.Windows.Forms.DockStyle.Left;
            this.buttonOrder.FlatAppearance.BorderSize = 0;
            this.buttonOrder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonOrder.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonOrder.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonOrder.Location = new System.Drawing.Point(200, 0);
            this.buttonOrder.Name = "buttonOrder";
            this.buttonOrder.Size = new System.Drawing.Size(200, 38);
            this.buttonOrder.TabIndex = 8;
            this.buttonOrder.Text = "Заказы";
            this.buttonOrder.UseVisualStyleBackColor = false;
            this.buttonOrder.Click += new System.EventHandler(this.buttonOrder_Click);
            this.buttonOrder.MouseEnter += new System.EventHandler(this.buttonOrder_MouseEnter);
            this.buttonOrder.MouseLeave += new System.EventHandler(this.buttonOrder_MouseLeave);
            // 
            // panelCatalog
            // 
            this.panelCatalog.AutoScroll = true;
            this.panelCatalog.BackColor = System.Drawing.Color.MediumPurple;
            this.panelCatalog.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelCatalog.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelCatalog.Location = new System.Drawing.Point(200, 0);
            this.panelCatalog.Name = "panelCatalog";
            this.panelCatalog.Size = new System.Drawing.Size(634, 423);
            this.panelCatalog.TabIndex = 11;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.BlueViolet;
            this.panel2.Controls.Add(this.buttonUpdate);
            this.panel2.Controls.Add(this.buttonSearch);
            this.panel2.Controls.Add(this.textBoxDo);
            this.panel2.Controls.Add(this.labelDo);
            this.panel2.Controls.Add(this.textBoxOt);
            this.panel2.Controls.Add(this.labelOt);
            this.panel2.Controls.Add(this.textBoxName);
            this.panel2.Controls.Add(this.labelName);
            this.panel2.Controls.Add(this.labelSearch);
            this.panel2.Controls.Add(this.buttonAddBal);
            this.panel2.Controls.Add(this.labelBal);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 423);
            this.panel2.TabIndex = 0;
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.BackColor = System.Drawing.Color.Indigo;
            this.buttonUpdate.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.buttonUpdate.FlatAppearance.BorderSize = 0;
            this.buttonUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonUpdate.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonUpdate.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonUpdate.Location = new System.Drawing.Point(0, 385);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(200, 38);
            this.buttonUpdate.TabIndex = 5;
            this.buttonUpdate.Text = "Обновить";
            this.buttonUpdate.UseVisualStyleBackColor = false;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
            this.buttonUpdate.MouseEnter += new System.EventHandler(this.buttonUpdate_MouseEnter);
            this.buttonUpdate.MouseLeave += new System.EventHandler(this.buttonUpdate_MouseLeave);
            // 
            // buttonSearch
            // 
            this.buttonSearch.BackColor = System.Drawing.Color.Indigo;
            this.buttonSearch.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonSearch.FlatAppearance.BorderSize = 0;
            this.buttonSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSearch.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonSearch.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonSearch.Location = new System.Drawing.Point(0, 294);
            this.buttonSearch.Name = "buttonSearch";
            this.buttonSearch.Size = new System.Drawing.Size(200, 30);
            this.buttonSearch.TabIndex = 4;
            this.buttonSearch.Text = "Найти";
            this.buttonSearch.UseVisualStyleBackColor = false;
            this.buttonSearch.Click += new System.EventHandler(this.buttonSearch_Click);
            this.buttonSearch.MouseEnter += new System.EventHandler(this.buttonSearch_MouseEnter);
            this.buttonSearch.MouseLeave += new System.EventHandler(this.buttonSearch_MouseLeave);
            // 
            // textBoxDo
            // 
            this.textBoxDo.Dock = System.Windows.Forms.DockStyle.Top;
            this.textBoxDo.Location = new System.Drawing.Point(0, 271);
            this.textBoxDo.Name = "textBoxDo";
            this.textBoxDo.Size = new System.Drawing.Size(200, 23);
            this.textBoxDo.TabIndex = 3;
            // 
            // labelDo
            // 
            this.labelDo.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelDo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelDo.ForeColor = System.Drawing.SystemColors.Control;
            this.labelDo.Location = new System.Drawing.Point(0, 246);
            this.labelDo.Name = "labelDo";
            this.labelDo.Size = new System.Drawing.Size(200, 25);
            this.labelDo.TabIndex = 5;
            this.labelDo.Text = "До";
            // 
            // textBoxOt
            // 
            this.textBoxOt.Dock = System.Windows.Forms.DockStyle.Top;
            this.textBoxOt.Location = new System.Drawing.Point(0, 223);
            this.textBoxOt.Name = "textBoxOt";
            this.textBoxOt.Size = new System.Drawing.Size(200, 23);
            this.textBoxOt.TabIndex = 2;
            // 
            // labelOt
            // 
            this.labelOt.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelOt.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelOt.ForeColor = System.Drawing.SystemColors.Control;
            this.labelOt.Location = new System.Drawing.Point(0, 198);
            this.labelOt.Name = "labelOt";
            this.labelOt.Size = new System.Drawing.Size(200, 25);
            this.labelOt.TabIndex = 3;
            this.labelOt.Text = "От";
            // 
            // textBoxName
            // 
            this.textBoxName.Dock = System.Windows.Forms.DockStyle.Top;
            this.textBoxName.Location = new System.Drawing.Point(0, 175);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(200, 23);
            this.textBoxName.TabIndex = 1;
            // 
            // labelName
            // 
            this.labelName.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelName.ForeColor = System.Drawing.SystemColors.Control;
            this.labelName.Location = new System.Drawing.Point(0, 150);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(200, 25);
            this.labelName.TabIndex = 1;
            this.labelName.Text = "Название";
            // 
            // labelSearch
            // 
            this.labelSearch.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelSearch.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelSearch.ForeColor = System.Drawing.SystemColors.Control;
            this.labelSearch.Location = new System.Drawing.Point(0, 98);
            this.labelSearch.Name = "labelSearch";
            this.labelSearch.Size = new System.Drawing.Size(200, 52);
            this.labelSearch.TabIndex = 0;
            this.labelSearch.Text = "Поиск";
            this.labelSearch.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // buttonAddBal
            // 
            this.buttonAddBal.BackColor = System.Drawing.Color.Indigo;
            this.buttonAddBal.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonAddBal.FlatAppearance.BorderSize = 0;
            this.buttonAddBal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddBal.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonAddBal.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonAddBal.Location = new System.Drawing.Point(0, 67);
            this.buttonAddBal.Name = "buttonAddBal";
            this.buttonAddBal.Size = new System.Drawing.Size(200, 31);
            this.buttonAddBal.TabIndex = 6;
            this.buttonAddBal.Text = "Пополнить баланс";
            this.buttonAddBal.UseVisualStyleBackColor = false;
            this.buttonAddBal.Click += new System.EventHandler(this.buttonAddBal_Click);
            this.buttonAddBal.MouseEnter += new System.EventHandler(this.buttonAddBal_MouseEnter);
            this.buttonAddBal.MouseLeave += new System.EventHandler(this.buttonAddBal_MouseLeave);
            // 
            // labelBal
            // 
            this.labelBal.BackColor = System.Drawing.Color.BlueViolet;
            this.labelBal.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelBal.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelBal.ForeColor = System.Drawing.SystemColors.Control;
            this.labelBal.Location = new System.Drawing.Point(0, 0);
            this.labelBal.MaximumSize = new System.Drawing.Size(200, 67);
            this.labelBal.Name = "labelBal";
            this.labelBal.Size = new System.Drawing.Size(200, 67);
            this.labelBal.TabIndex = 8;
            // 
            // timerLastUserInput
            // 
            this.timerLastUserInput.Interval = 60000;
            this.timerLastUserInput.Tick += new System.EventHandler(this.timerLastUserInput_Tick);
            // 
            // timerUpdateAuthKey
            // 
            this.timerUpdateAuthKey.Interval = 900000;
            this.timerUpdateAuthKey.Tick += new System.EventHandler(this.timerUpdateAuthKey_Tick);
            // 
            // Catalog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(834, 461);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panelCatalog);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "Catalog";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Southern Beauty";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Catalog_FormClosed);
            this.Load += new System.EventHandler(this.Catalog_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonChangePassword;
        private System.Windows.Forms.Button buttonCart;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panelCatalog;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button buttonOrder;
        private System.Windows.Forms.Button buttonSearch;
        private System.Windows.Forms.TextBox textBoxDo;
        private System.Windows.Forms.Label labelDo;
        private System.Windows.Forms.TextBox textBoxOt;
        private System.Windows.Forms.Label labelOt;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label labelSearch;
        private System.Windows.Forms.Button buttonAddBal;
        private System.Windows.Forms.Label labelBal;
        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.Timer timerLastUserInput;
        private System.Windows.Forms.Timer timerUpdateAuthKey;
    }
}