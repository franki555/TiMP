﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Client
{
    public partial class AddBalance : Form
    {
        /// <summary>
        /// Variables
        /// </summary>

        Catalog catalog = null;

        /// <summary>
        /// Methods related to the form
        /// </summary>

        public AddBalance(Catalog main)
        {
            InitializeComponent();

            catalog = main;

            labelSum.BackColor = Color.Transparent;
            labelSum.Font = new Font(labelSum.Font, labelSum.Font.Style | FontStyle.Bold);

            labelCard.BackColor = Color.Transparent;
            labelCard.Font = new Font(labelCard.Font, labelCard.Font.Style | FontStyle.Bold);
        }

        private void buttonAddBal_Click(object sender, EventArgs e)
        {
            AddBal();
        }

        private void buttonAddBal_MouseEnter(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseEnterButton(sender);
        }

        private void buttonAddBal_MouseLeave(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseLeaveButton(sender);
        }

        private void buttonCancel_MouseEnter(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseEnterButton(sender);
        }

        private void buttonCancel_MouseLeave(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseLeaveButton(sender);
        }

        private void AddBalance_FormClosed(object sender, FormClosedEventArgs e)
        {
            Hide();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            Hide();
        }

        private void textBoxSum_KeyPress(object sender, KeyPressEventArgs e)
        {
            PressEnter(e);
        }

        private void textBoxCard_KeyPress(object sender, KeyPressEventArgs e)
        {
            PressEnter(e);
        }

        /// <summary>
        /// Others methods
        /// </summary>

        private void AddBal()
        {
            int id_user = catalog.Id_user;
            int sum;
            string card;

            try
            {
                sum = Convert.ToInt32(textBoxSum.Text);
                card = textBoxCard.Text.ToString();

                foreach (var sym in card)
                {
                    if (!char.IsDigit(sym))
                        throw new Exception();
                }
            }
            catch
            {
                MessageBox.Show("Значения должны быть целочисленными!");
                return;
            }

            if (card.Length != 16)
            {
                MessageBox.Show("Недействительный номер карты!");
                return;
            }
            if (sum <= 0)
            {
                MessageBox.Show("Сумма должна быть больше 0");
                return;
            }

            SslTcpServer client = new SslTcpServer(
                ServerInformation.IpServer, ServerInformation.Port
                );

            if (client.Client == null)
            {
                catalog.Id_user = 0;
                catalog.AuthKey = "";
                catalog.Bal = 0;
                MessageBox.Show("Не удалось соеденится с сервером");
                Application.Exit();
            }

            string request = $"/addBalance {id_user} {catalog.AuthKey} {sum} {card}";
            client.SendMessage(request);
            string response = client.ReadMessage();
            client.SendMessage("<END>");
            client.Close();

            if (response == "0")
            {
                MessageBox.Show("Баланс не был пополнен");
                return;
            }
            else
            {
                catalog.LabelBal.Text = (catalog.Bal + sum).ToString();
                catalog.Bal += sum;
                MessageBox.Show($"Баланс был пополнен на {sum} рублей");
            }
        }

        private void PressEnter(KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                buttonAddBal.PerformClick();
            }
        }

    }
}