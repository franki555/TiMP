﻿namespace Client
{
    public static class ProductDisplayConfiguration
    {
        /// <summary>
        /// Configuration of the location of products in the catalog
        /// </summary>

        public static class Catalog
        {
            public const int vDelta = Image.SizeY + 16;

            public static class Image
            {
                public const int StartPosX = 32;
                public const int StartPosY = 16;

                public const int SizeX = 156;
                public const int SizeY = 208;
            }

            public static class ProductDetails
            {
                public const int StartPosX = 196;
                public const int StartPosY = 20;

                public const int SizeX = 208;
                public const int SizeY = 204;
            }

            public static class ButtonAddCart
            {
                public const int StartPosX = 412;
                public const int StartPosY = 16;

                public const int SizeX = 156;
                public const int SizeY = 208;
            }
        }

        /// <summary>
        /// Configuration of the location of products in the cart
        /// </summary>

        public static class Cart
        {
            public const int vDelta = Image.SizeY + 8;

            public static class Image
            {
                public const int StartPosX = 8;
                public const int StartPosY = 8;

                public const int SizeX = 156;
                public const int SizeY = 208;
            }

            public static class ProductDetails
            {
                public const int StartPosX = 168;
                public const int StartPosY = 12;

                public const int SizeX = 183;
                public const int SizeY = 179;
            }

            public static class NumericUpDownCount
            {
                public const int StartPosX = 168;
                public const int StartPosY = 192;

                public const int SizeX = 84;
                public const int SizeY = 25;
            }

            public static class ButtonDeleteProduct
            {
                public const int StartPosX = 353;
                public const int StartPosY = 10;

                public const int SizeX = 25;
                public const int SizeY = 25;
            }

            public static class ButtonBuy
            {
                public const int StartPosX = 252;
                public const int StartPosY = 190;

                public const int SizeX = 124;
                public const int SizeY = 27;
            }
        }

        /// <summary>
        /// Configuration of the location of products in the order
        /// </summary>

        public static class Order
        {
            public const int vDelta = Image.SizeY + 8;

            public static class Image
            {
                public const int StartPosX = 8;
                public const int StartPosY = 8;

                public const int SizeX = 156;
                public const int SizeY = 208;
            }

            public static class OrderDetails
            {
                public const int StartPosX = 168;
                public const int StartPosY = 8;

                public const int SizeX = 156;
                public const int SizeY = 238;
            }
        }
    }
}