﻿
namespace Client
{
    partial class AddBalance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAddBal = new System.Windows.Forms.Button();
            this.textBoxCard = new System.Windows.Forms.TextBox();
            this.labelCard = new System.Windows.Forms.Label();
            this.textBoxSum = new System.Windows.Forms.TextBox();
            this.labelSum = new System.Windows.Forms.Label();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonAddBal
            // 
            this.buttonAddBal.BackColor = System.Drawing.Color.Indigo;
            this.buttonAddBal.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.buttonAddBal.FlatAppearance.BorderSize = 0;
            this.buttonAddBal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddBal.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonAddBal.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonAddBal.Location = new System.Drawing.Point(0, 337);
            this.buttonAddBal.Name = "buttonAddBal";
            this.buttonAddBal.Size = new System.Drawing.Size(334, 37);
            this.buttonAddBal.TabIndex = 3;
            this.buttonAddBal.Text = "Пополнить баланс";
            this.buttonAddBal.UseVisualStyleBackColor = false;
            this.buttonAddBal.Click += new System.EventHandler(this.buttonAddBal_Click);
            this.buttonAddBal.MouseEnter += new System.EventHandler(this.buttonAddBal_MouseEnter);
            this.buttonAddBal.MouseLeave += new System.EventHandler(this.buttonAddBal_MouseLeave);
            // 
            // textBoxCard
            // 
            this.textBoxCard.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.textBoxCard.Location = new System.Drawing.Point(0, 314);
            this.textBoxCard.Name = "textBoxCard";
            this.textBoxCard.Size = new System.Drawing.Size(334, 23);
            this.textBoxCard.TabIndex = 2;
            this.textBoxCard.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCard_KeyPress);
            // 
            // labelCard
            // 
            this.labelCard.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.labelCard.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelCard.ForeColor = System.Drawing.SystemColors.Control;
            this.labelCard.Location = new System.Drawing.Point(0, 284);
            this.labelCard.Name = "labelCard";
            this.labelCard.Size = new System.Drawing.Size(334, 30);
            this.labelCard.TabIndex = 2;
            this.labelCard.Text = "Номер карты";
            // 
            // textBoxSum
            // 
            this.textBoxSum.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.textBoxSum.Location = new System.Drawing.Point(0, 261);
            this.textBoxSum.Name = "textBoxSum";
            this.textBoxSum.Size = new System.Drawing.Size(334, 23);
            this.textBoxSum.TabIndex = 1;
            this.textBoxSum.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxSum_KeyPress);
            // 
            // labelSum
            // 
            this.labelSum.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.labelSum.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelSum.ForeColor = System.Drawing.SystemColors.Control;
            this.labelSum.Location = new System.Drawing.Point(0, 231);
            this.labelSum.Name = "labelSum";
            this.labelSum.Size = new System.Drawing.Size(334, 30);
            this.labelSum.TabIndex = 4;
            this.labelSum.Text = "Сумма";
            // 
            // buttonCancel
            // 
            this.buttonCancel.BackColor = System.Drawing.Color.Indigo;
            this.buttonCancel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.buttonCancel.FlatAppearance.BorderSize = 0;
            this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCancel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonCancel.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonCancel.Location = new System.Drawing.Point(0, 374);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(334, 37);
            this.buttonCancel.TabIndex = 4;
            this.buttonCancel.Text = "Отмена";
            this.buttonCancel.UseVisualStyleBackColor = false;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            this.buttonCancel.MouseEnter += new System.EventHandler(this.buttonCancel_MouseEnter);
            this.buttonCancel.MouseLeave += new System.EventHandler(this.buttonCancel_MouseLeave);
            // 
            // AddBalance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Client.Properties.Resources.nhnN3RBA_t5byf1l_Hq_F7zzoLO_B8uIBThnl4SuLVGGaB7cYYuyuIfBWfesY6LPzt4_9jCyVaWtzUr3bAhrC_rK;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(334, 411);
            this.Controls.Add(this.labelSum);
            this.Controls.Add(this.textBoxSum);
            this.Controls.Add(this.labelCard);
            this.Controls.Add(this.textBoxCard);
            this.Controls.Add(this.buttonAddBal);
            this.Controls.Add(this.buttonCancel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "AddBalance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Пополнить счет";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.AddBalance_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonAddBal;
        private System.Windows.Forms.TextBox textBoxCard;
        private System.Windows.Forms.Label labelCard;
        private System.Windows.Forms.TextBox textBoxSum;
        private System.Windows.Forms.Label labelSum;
        private System.Windows.Forms.Button buttonCancel;
    }
}