﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Client
{
    public static class GetCart
    {
        public class ProductInfo
        {
            public int id;
            public string name;
            public int price;
            public int countProduct;
            public byte[] image;
        }

        public class BlockProduct
        {
            public PictureBox pictureBoxImage;
            public Label labelProductDetails;
            public NumericUpDown numericUpDownCount;
            public Button buttonDeleteProduct;
            public Button buttonBuy;
        }

        public static ProductInfo GetProductInfo(
            SslTcpServer client, int id_user, string authKey, int id_prod)
        {
            if(client.Client == null)
            {
                client = new SslTcpServer(ServerInformation.IpServer, ServerInformation.Port);
            }

            string request = $"/getCart {id_user} {authKey} {id_prod}";
            client.SendMessage(request);
            if (!(client.ReadMessage() is string response))
            {
                return null;
            }

            ProductInfo productInfo = new ProductInfo();

            if (response != "0" && response != "-1")
            {
                List<string> data = SplitString.split(response);
                productInfo.id = Convert.ToInt32(data[0]);
                productInfo.name = data[1].Replace("|", " ");
                productInfo.price = Convert.ToInt32(data[2]);
                productInfo.countProduct = Convert.ToInt32(data[3]);

                request = $"/getImage {productInfo.id}";
                client.SendMessage(request);
                response = client.ReadMessage();

                if (response != "0" && response != "-1")
                {
                    productInfo.image = Convert.FromBase64String(response);
                }
            }
            else
            {
                productInfo = null;
            }
            return productInfo;
        }

        public static BlockProduct GetProductBlock(ProductInfo productInfo, int pos_product)
        {
            if (productInfo == null)
            {
                return null;
            }

            PictureBox pictureBox = new PictureBox();
            pictureBox.Location = new Point(ProductDisplayConfiguration.Cart.Image.StartPosX,
                ProductDisplayConfiguration.Cart.Image.StartPosY +
                pos_product * ProductDisplayConfiguration.Cart.vDelta);
            pictureBox.Width = ProductDisplayConfiguration.Cart.Image.SizeX;
            pictureBox.Height = ProductDisplayConfiguration.Cart.Image.SizeY;
            if (productInfo.image != null)
            {
                MemoryStream memoryStream = new MemoryStream(productInfo.image);
                pictureBox.Image = Image.FromStream(memoryStream);
            }
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.BorderStyle = BorderStyle.FixedSingle;
            pictureBox.BackColor = Color.White;

            Label label = new Label();
            label.Location = new Point(ProductDisplayConfiguration.Cart.ProductDetails.StartPosX,
                ProductDisplayConfiguration.Cart.ProductDetails.StartPosY +
                pos_product * ProductDisplayConfiguration.Cart.vDelta);
            label.Width = ProductDisplayConfiguration.Cart.ProductDetails.SizeX;
            label.Height = ProductDisplayConfiguration.Cart.ProductDetails.SizeY;
            label.MaximumSize = new Size(ProductDisplayConfiguration.Cart.ProductDetails.SizeX,
                ProductDisplayConfiguration.Cart.ProductDetails.SizeY);
            label.Font = new Font("Segoe UI Black", 12F,
                (FontStyle.Bold | FontStyle.Italic), GraphicsUnit.Point);
            label.ForeColor = Color.White;
            label.Text = $"{productInfo.name}\n" +
                $"Цена: {productInfo.price}р за 1 шт.\n" +
                $"В наличии: {productInfo.countProduct}";

            NumericUpDown numericUpDown = new NumericUpDown();
            numericUpDown.Location = new Point(ProductDisplayConfiguration.Cart.NumericUpDownCount.StartPosX,
                ProductDisplayConfiguration.Cart.NumericUpDownCount.StartPosY +
                pos_product * ProductDisplayConfiguration.Cart.vDelta);
            numericUpDown.Width = ProductDisplayConfiguration.Cart.NumericUpDownCount.SizeX;
            numericUpDown.Height = ProductDisplayConfiguration.Cart.NumericUpDownCount.SizeY;
            numericUpDown.Minimum = 0;
            numericUpDown.Maximum = productInfo.countProduct;
            numericUpDown.Value = 0;
            numericUpDown.Tag = productInfo.id;

            Button buttonDel = new Button();
            buttonDel.Location = new Point(ProductDisplayConfiguration.Cart.ButtonDeleteProduct.StartPosX,
                ProductDisplayConfiguration.Cart.ButtonDeleteProduct.StartPosY +
                pos_product * ProductDisplayConfiguration.Cart.vDelta);
            buttonDel.Width = ProductDisplayConfiguration.Cart.ButtonDeleteProduct.SizeX;
            buttonDel.Height = ProductDisplayConfiguration.Cart.ButtonDeleteProduct.SizeY;
            buttonDel.Font = new Font("Segoe UI Black", 12F,
                (FontStyle.Bold | FontStyle.Italic));
            buttonDel.FlatStyle = FlatStyle.Flat;
            buttonDel.FlatAppearance.BorderSize = 0;
            buttonDel.BackColor = Color.Indigo;
            buttonDel.ForeColor = Color.White;
            buttonDel.Tag = productInfo.id;
            buttonDel.Text = "X";

            Button buttonBuy = new Button();
            buttonBuy.Location = new Point(ProductDisplayConfiguration.Cart.ButtonBuy.StartPosX,
                ProductDisplayConfiguration.Cart.ButtonBuy.StartPosY +
                pos_product * ProductDisplayConfiguration.Cart.vDelta);
            buttonBuy.Width = ProductDisplayConfiguration.Cart.ButtonBuy.SizeX;
            buttonBuy.Height = ProductDisplayConfiguration.Cart.ButtonBuy.SizeY;
            buttonBuy.Font = new Font("Segoe UI Black", 10F,
                (FontStyle.Bold | FontStyle.Italic));
            buttonBuy.FlatStyle = FlatStyle.Flat;
            buttonBuy.FlatAppearance.BorderSize = 0;
            buttonBuy.BackColor = Color.Indigo;
            buttonBuy.ForeColor = Color.White;
            buttonBuy.Tag = productInfo.id;
            buttonBuy.Text = "Купить";

            BlockProduct blockProduct = new BlockProduct();
            blockProduct.pictureBoxImage = pictureBox;
            blockProduct.labelProductDetails = label;
            blockProduct.numericUpDownCount = numericUpDown;
            blockProduct.buttonDeleteProduct = buttonDel;
            blockProduct.buttonBuy = buttonBuy;

            return blockProduct;
        }
    }
}