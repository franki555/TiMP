﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Client
{
    public partial class Login : Form
    {
        /// <summary>
        /// Methods related to the form
        /// </summary>

        public Login()
        {
            InitializeComponent();

            labelLogin.BackColor = Color.Transparent;
            labelLogin.Font = new Font(labelLogin.Font, labelLogin.Font.Style | FontStyle.Bold);

            labelPassword.BackColor = Color.Transparent;
            labelPassword.Font = new Font(labelLogin.Font, labelLogin.Font.Style | FontStyle.Bold);
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            _Login();
        }

        private void buttonRegister_Click(object sender, EventArgs e)
        {
            Register register = new Register(this);
            register.Show();
            Hide();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Login_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void textBoxLogin_KeyPress(object sender, KeyPressEventArgs e)
        {
            PressEnter(e);
        }

        private void textBoxPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            PressEnter(e);
        }

        private void Login_Load(object sender, EventArgs e)
        {
            SslTcpServer client = new SslTcpServer(
                ServerInformation.IpServer, ServerInformation.Port
                );

            if (client.Client == null)
            {
                MessageBox.Show("Сервер временно не доступен. Попробуйте позже!");
                Application.Exit();
            }
            else
            {
                client.Close();
            }
        }

        /// <summary>
        /// Others methods
        /// </summary>
    
        private void _Login()
        {
            string login = textBoxLogin.Text.ToString();
            string password = textBoxPassword.Text.ToString();

            if ((login.IndexOf(' ') > -1) || (password.IndexOf(' ') > -1))
                MessageBox.Show("Поля не должны содержать пробелы!");
            else if ((!string.IsNullOrEmpty(textBoxPassword.Text) && !string.IsNullOrWhiteSpace(textBoxPassword.Text))
                && (!string.IsNullOrEmpty(textBoxLogin.Text) && !string.IsNullOrWhiteSpace(textBoxLogin.Text)))
            {
                SslTcpServer client = new SslTcpServer(
                    ServerInformation.IpServer, ServerInformation.Port
                    );

                if (client.Client == null)
                {
                    MessageBox.Show("Не удалось соеденится с сервером");
                    Application.Exit();
                }

                string request = $"/login {login} {password}";
                client.SendMessage(request);
                string response = client.ReadMessage();
                client.SendMessage("<END>");
                client.Close();

                if (response == "0")
                {
                    MessageBox.Show("Неверное имя пользователя или пароль!");
                }
                else if (response == "-1")
                {
                    MessageBox.Show("Обнаружена SQL Injection!");
                }
                else if (response == "-5")
                {
                    MessageBox.Show("Введите значение от 6 до 16");
                }
                else
                {
                    List<string> data = SplitString.split(response);

                    Catalog catalog = new Catalog(
                        Convert.ToInt32(data[0]), data[1], Convert.ToInt32(data[2])
                        );

                    catalog.Login = this;
                    catalog.Show();
                    Hide();

                    textBoxLogin.Text = "";
                    textBoxPassword.Text = "";
                }
            }
            else
            {
                MessageBox.Show("Все поля должны быть заполены!");
            }
        }

        private void PressEnter(KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                buttonLogin.PerformClick();
            }
        }
    }
}