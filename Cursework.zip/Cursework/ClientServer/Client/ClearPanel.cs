﻿using System.Windows.Forms;

namespace Client
{
    public static class ClearPanel
    {
        public static void Сlear(Panel panel)
        {
            for (int i = 0; i < panel.Controls.Count; i++)
            {
                panel.Controls[i].Enabled = false;
                panel.Controls[i].Dispose();
                i--;
            }
        }
    }
}