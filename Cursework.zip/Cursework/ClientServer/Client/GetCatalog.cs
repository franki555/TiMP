﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Client
{
    public static class GetCatalog
    {
        public class ProductInfo
        {
            public int id;
            public string name;
            public int price;
            public int countProduct;
            public byte[] image;
        }

        public class BlockProduct
        {
            public PictureBox pictureBoxImage;
            public Label labelProductDetails;
            public Button buttonAddCart;
        }

        public static ProductInfo GetProductInfo(SslTcpServer client, int id_prod)
        {
            if (client.Client == null)
            {
                client = new SslTcpServer(ServerInformation.IpServer, ServerInformation.Port);
            }

            string request = $"/getProduct {id_prod}";
            client.SendMessage(request);
            if (!(client.ReadMessage() is string response))
            {
                return null;
            }

            ProductInfo productInfo = new ProductInfo();

            if (response != "0" && response != "-1")
            {
                List<string> data = SplitString.split(response);

                productInfo.id = Convert.ToInt32(data[0]);
                productInfo.name = data[1].Replace("|", " ");
                productInfo.price = Convert.ToInt32(data[2]);
                productInfo.countProduct = Convert.ToInt32(data[3]);

                request = $"/getImage {productInfo.id}";
                client.SendMessage(request);
                response = client.ReadMessage();

                if (response != "0" && response != "-1")
                {
                    productInfo.image = Convert.FromBase64String(response);
                }
            }
            else
            {
                productInfo = null;
            }
            return productInfo;
        }
       
        public static BlockProduct GetProductBlock(ProductInfo productInfo, int pos_product)
        {
            if (productInfo == null)
            {
                return null;
            }

            PictureBox pictureBox = new PictureBox();
            pictureBox.Location = new Point(ProductDisplayConfiguration.Catalog.Image.StartPosX,
                ProductDisplayConfiguration.Catalog.Image.StartPosY +
                pos_product * ProductDisplayConfiguration.Catalog.vDelta);
            pictureBox.Width = ProductDisplayConfiguration.Catalog.Image.SizeX;
            pictureBox.Height = ProductDisplayConfiguration.Catalog.Image.SizeY;
            if (productInfo.image != null)
            {
                MemoryStream memoryStream = new MemoryStream(productInfo.image);
                pictureBox.Image = Image.FromStream(memoryStream);
            }
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.BorderStyle = BorderStyle.FixedSingle;
            pictureBox.BackColor = Color.White;

            Label label = new Label();
            label.Location = new Point(ProductDisplayConfiguration.Catalog.ProductDetails.StartPosX,
                ProductDisplayConfiguration.Catalog.ProductDetails.StartPosY +
                pos_product * ProductDisplayConfiguration.Catalog.vDelta);
            label.Width = ProductDisplayConfiguration.Catalog.ProductDetails.SizeX;
            label.Height = ProductDisplayConfiguration.Catalog.ProductDetails.SizeY;
            label.MaximumSize = new Size(ProductDisplayConfiguration.Catalog.ProductDetails.SizeX,
                ProductDisplayConfiguration.Catalog.ProductDetails.SizeY);
            label.Font = new Font("Segoe UI Black", 12F,
                (FontStyle.Bold | FontStyle.Italic), GraphicsUnit.Point);
            label.ForeColor = Color.White;
            label.Text = $"{productInfo.name}\n" +
                $"Цена: {productInfo.price}р за шт.\n" +
                $"В наличии: {productInfo.countProduct}";

            Button button = new Button();
            button.Location = new Point(ProductDisplayConfiguration.Catalog.ButtonAddCart.StartPosX,
                ProductDisplayConfiguration.Catalog.ButtonAddCart.StartPosY +
                pos_product * ProductDisplayConfiguration.Catalog.vDelta);
            button.Width = ProductDisplayConfiguration.Catalog.ButtonAddCart.SizeX;
            button.Height = ProductDisplayConfiguration.Catalog.ButtonAddCart.SizeY;
            button.Font = new Font("Segoe UI Black", 12F,
                (FontStyle.Bold | FontStyle.Italic));
            button.ForeColor = Color.White;
            button.BackColor = Color.Indigo;
            button.FlatAppearance.BorderSize = 0;
            button.FlatStyle = FlatStyle.Flat;
            button.Tag = productInfo.id;
            button.Text = "Добавить\n" +
                "в корзину";

            BlockProduct blockProduct = new BlockProduct();
            blockProduct.pictureBoxImage = pictureBox;
            blockProduct.labelProductDetails = label;
            blockProduct.buttonAddCart = button;

            return blockProduct;
        }
    }
}