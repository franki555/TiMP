﻿using System.Collections.Generic;

namespace Client
{
    static class SplitString
    {
        public static List<string> split(string str)
        {
            List<string> res = new List<string>();
            string buffer = "";
            for (int i = 0; i < str.Length; i++)
            {
                if (str[i] == ' ')
                {
                    res.Add(buffer);
                    buffer = "";
                }
                else
                {
                    buffer += str[i];
                }
            }
            res.Add(buffer);
            return res;
        }
    }
}