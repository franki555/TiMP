﻿using System;
using System.Windows.Forms;

namespace Client
{
    public partial class BuyProducConfirm : Form
    {
        /// <summary>
        /// Variables
        /// </summary>

        Catalog catalog = null;
        private Cart cart;
        private int id_user;
        private string authKey;
        private int id_product;
        private int count;

        /// <summary>
        /// Methods related to the form
        /// </summary>

        public BuyProducConfirm(
            Catalog __catalog, Cart __cart, int __id_user, string __authKey, int __id_product, int __count
            )
        {
            InitializeComponent();

            catalog = __catalog;
            cart = __cart;
            id_user = __id_user;
            authKey = __authKey;
            id_product = __id_product;
            count = __count;

            dateTimePickerDate.MinDate = DateTime.Now;
        }

        private void buttonConfirm_MouseEnter(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseEnterButton(sender);
        }

        private void buttonConfirm_MouseLeave(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseLeaveButton(sender);
        }

        private void buttonCancel_MouseEnter(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseEnterButton(sender);
        }

        private void buttonCancel_MouseLeave(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseLeaveButton(sender);
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            Hide();
        }

        private void buttonConfirm_Click(object sender, EventArgs e)
        {
            Confirm();
        }

        /// <summary>
        /// Others methods
        /// </summary>
        
        private void Confirm()
        {
            string address_index = textBoxAddress.Text.ToString();
            string dateTime = dateTimePickerDate.Value.Date.ToString("d");

            if (address_index.Length != 6 || dateTime == "")
            {
                MessageBox.Show("Введите корректные данные!");
                return;
            }

            SslTcpServer client = new SslTcpServer(
                ServerInformation.IpServer, ServerInformation.Port
                );

            if (client.Client == null)
            {
                catalog.Id_user = 0;
                catalog.AuthKey = "";
                catalog.Bal = 0;
                MessageBox.Show("Не удалось соеденится с сервером");
                Application.Exit();
            }

            string request = $"/buyProduct" +
                $" {id_user} {authKey} {id_product} {count} {address_index} {dateTime}";
            client.SendMessage(request);
            string response = client.ReadMessage();
            client.SendMessage("<END>");
            client.Close();

            if (response == "-1" || response == "0")
            {
                MessageBox.Show("Не удалось совершить покупку, попробуйте позже!");
                Hide();
                return;
            }
            else if (response == "-3")
            {
                MessageBox.Show("Такого колличества товара нет в наличии\nПопробуйте ввести меньше!");
                Hide();
                return;
            }
            else if (response == "-4")
            {
                MessageBox.Show("На вашем счете недостаточно средств!");
                Hide();
                return;
            }
            else
            {
                MessageBox.Show($"Покупка успешно совершена!\n" +
                    $"Заказ зарегестрирован под номером {response}");
                cart.CartUpdate();
                Hide();
                return;
            }
        }

    }
}