﻿namespace Client
{
    class ServerInformation
    {
        private const string ipServer = "127.0.0.1";
        private const int port = 7777;
        public static string IpServer { get { return ipServer; } }
        public static int Port { get { return port; } }
    }
}