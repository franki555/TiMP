﻿using System.Drawing;
using System.Windows.Forms;

namespace Client
{
    public partial class ChangePassword : Form
    {
        /// <summary>
        /// Variables
        /// </summary>

        Catalog catalog = null;

        /// <summary>
        /// Methods related to the form
        /// </summary>

        public ChangePassword(Catalog main)
        {
            InitializeComponent();

            this.catalog = main;

            labelOldPsw.BackColor = Color.Transparent;
            labelOldPsw.Font = new Font(labelOldPsw.Font, labelOldPsw.Font.Style | FontStyle.Bold);

            labelNewPsw.BackColor = Color.Transparent;
            labelNewPsw.Font = new Font(labelNewPsw.Font, labelNewPsw.Font.Style | FontStyle.Bold);

            labelConfirm.BackColor = Color.Transparent;
            labelConfirm.Font = new Font(labelConfirm.Font, labelConfirm.Font.Style | FontStyle.Bold);
        }

        private void buttonChange_Click(object sender, System.EventArgs e)
        {
            ChangePass();
        }

        private void buttonCancel_Click(object sender, System.EventArgs e)
        {
            Hide();
        }

        private void ChangePassword_FormClosed(object sender, FormClosedEventArgs e)
        {
            Hide();
        }

        private void textBoxOldPsw_KeyPress(object sender, KeyPressEventArgs e)
        {
            PressEnter(e);
        }

        private void textBoxNewPsw_KeyPress(object sender, KeyPressEventArgs e)
        {
            PressEnter(e);
        }

        private void textBoxConfirm_KeyPress(object sender, KeyPressEventArgs e)
        {
            PressEnter(e);
        }

        private void buttonChange_MouseEnter(object sender, System.EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseEnterButton(sender);
        }

        private void buttonChange_MouseLeave(object sender, System.EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseLeaveButton(sender);
        }

        private void buttonCancel_MouseEnter(object sender, System.EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseEnterButton(sender);
        }

        private void buttonCancel_MouseLeave(object sender, System.EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseLeaveButton(sender);
        }

        /// <summary>
        /// Others methods
        /// </summary>

        private void ChangePass()
        {
            string oldPsw = textBoxOldPsw.Text.ToString();
            string newPsw = textBoxNewPsw.Text.ToString();
            string confirmPsw = textBoxConfirm.Text.ToString();

            if ((oldPsw.IndexOf(' ') > -1) ||
                (newPsw.IndexOf(' ') > -1) ||
                (confirmPsw.IndexOf(' ') > -1))
            {
                MessageBox.Show("Поля не должны содержать пробелы!");
            }
            else if (oldPsw == newPsw)
            {
                MessageBox.Show("Новый пароль должен отличатся от старого!");
            }
            else if ((!string.IsNullOrEmpty(textBoxOldPsw.Text) && !string.IsNullOrWhiteSpace(textBoxOldPsw.Text))
                && (!string.IsNullOrEmpty(textBoxNewPsw.Text) && !string.IsNullOrWhiteSpace(textBoxNewPsw.Text))
                && (!string.IsNullOrEmpty(textBoxConfirm.Text) && !string.IsNullOrWhiteSpace(textBoxConfirm.Text)))
            {
                if (newPsw == confirmPsw)
                {
                    SslTcpServer client = new SslTcpServer(
                        ServerInformation.IpServer, ServerInformation.Port
                        );

                    if (client.Client == null)
                    {
                        catalog.Id_user = 0;
                        catalog.AuthKey = "";
                        catalog.Bal = 0;
                        MessageBox.Show("Не удалось соеденится с сервером");
                        Application.Exit();
                    }

                    string request = $"/changePswd {catalog.Id_user}" +
                        $" {catalog.AuthKey} {newPsw} {oldPsw}";
                    client.SendMessage(request);
                    string response = client.ReadMessage();
                    client.SendMessage("<END>");
                    client.Close();

                    if (response == "1")
                    {
                        MessageBox.Show("Пароль успешно изменен!");
                        Hide();
                        catalog.Show();
                    }
                    else if (response == "-1")
                    {
                        MessageBox.Show("Обнаружена SQL Injection!");
                    }
                    else if (response == "-5")
                    {
                        MessageBox.Show("Введите значение от 6 до 16");
                    }
                    else
                    {
                        MessageBox.Show("Пароль не изменен!");
                    }
                }
                else
                {
                    MessageBox.Show("Пароли не совпадают!");
                }
            }
        }

        private void PressEnter(KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                buttonChange.PerformClick();
            }
        }

    }
}