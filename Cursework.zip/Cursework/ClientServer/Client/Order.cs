﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client
{
    public partial class Order : Form
    {
        /// <summary>
        /// Variables
        /// </summary>

        Catalog catalog = null;

        /// <summary>
        /// Methods related to the form
        /// </summary>

        public Order(Catalog __catalog)
        {
            InitializeComponent();

            catalog = __catalog;
        }

        private void buttonExit_MouseEnter(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseEnterButton(sender);
        }

        private void buttonExit_MouseLeave(object sender, EventArgs e)
        {
            MouseEnterAndLeaveButton.MouseLeaveButton(sender);
        }

        private void Order_FormClosed(object sender, FormClosedEventArgs e)
        {
            Hide();
        }

        private void Order_Load(object sender, EventArgs e)
        {
            FillProductsWithPanel();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Hide();
        }

        /// <summary>
        /// Other methods
        /// </summary>

        private async void FillProductsWithPanel()
        {
            SslTcpServer client = new SslTcpServer(
                ServerInformation.IpServer, ServerInformation.Port
                );

            if (client.Client == null)
            {
                catalog.Id_user = 0;
                catalog.AuthKey = "";
                catalog.Bal = 0;
                MessageBox.Show("Не удалось соеденится с сервером");
                Application.Exit();
            }

            List<GetOrder.OrderInfo> orders = new List<GetOrder.OrderInfo>();

            int id_order = 0;
            while (true)
            {
                if (await Task.Run(() => GetOrder.GetOrderInfo
                (client, catalog.Id_user, catalog.AuthKey, id_order)) is
                    GetOrder.OrderInfo order)
                {
                    orders.Add(order);
                    id_order = order.id;
                }
                else
                {
                    break;
                }
            }

            client.SendMessage("<END>");
            client.Close();

            for (int i = orders.Count - 1; i > -1; i--)
            {
                if (await Task.Run(() => GetOrder.GetOrderBlock(orders[i], orders.Count - i - 1)) is
                    GetOrder.BlockOrder blockOrder)
                {
                    SuspendLayout();
                    panelOrder.Controls.Add(blockOrder.pictureBoxImage);
                    panelOrder.Controls.Add(blockOrder.labelOrderDetails);
                    ResumeLayout();
                }
            }

            if (panelOrder.Controls.Count == 0)
            {
                MessageBox.Show("Ваш список заказов пуст!");
            }
        }

    }
}