﻿using System;

namespace Server
{
    /// <summary>
    /// Класс для проверки строки
    /// На специальные символы
    /// В частности на SQL Injection
    /// </summary>

    public static class CheckStringForChar
    {
        public static Boolean CheckForSQLInjection(string userInput)
        {
            string[] CheckList =
            {
                "--",
                ";--",
                ";",
                "/*",
                "*/",
                "@@",
                "@",
                "char",
                "nchar",
                "varchar",
                "nvarchar",
                "alter",
                "begin",
                "cast",
                "create",
                "cursor",
                "declare",
                "delete",
                "drop",
                "end",
                "exec",
                "execute",
                "fetch",
                "insert",
                "kill",
                "select",
                "sys",
                "sysobjects",
                "syscolumns",
                "table",
                "update"
            };
            return CheckString(userInput.Trim(), CheckList);
        }

        private static bool CheckString(string userInput, string[] checkList)
        {
            bool isFindChar = false;

            string CheckString = userInput.Replace("'", "''");

            for (int i = 0; i < checkList.Length; i++)
            {
                if (CheckString.IndexOf(checkList[i], StringComparison.OrdinalIgnoreCase) > -1)
                {
                    isFindChar = true;
                    break;
                }
            }
            return isFindChar;
        }
    }
}