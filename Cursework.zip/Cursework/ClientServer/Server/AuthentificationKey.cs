﻿using System;

namespace Server
{
    /// <summary>
    /// Модуль для генерации ключа аутентификации
    /// Сгенерированая строка кодируется SHA256
    /// Для большей надежности
    /// </summary>

    public static class AuthentificationKey
    {
        private const int authKeyLength = 16;
        private const string alphabet =
            "QqWwEeRrTtYyUuIiOoPp{[}]AaSsDdFfGgHhJjKkLl:;'ZzXxCcVvBbNnMm<,>.?/'" +
            "1234567890!@#$%^&*()_+-=`~";

        public static string GetAuthKey()
        {
            Random rnd = new Random();
            string authKey = "";

            for(int i = 0; i < authKeyLength; i++)
            {
                authKey += alphabet[rnd.Next() % alphabet.Length];
            }

            return MySHA256.Hash(authKey);
        }
    }
}