﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace Server
{
    /// <summary>
    /// Модуль отвечающий за запуск сервера
    /// Когда подключается новый клиент
    /// Работа с ним выводится в отдельный поток
    /// </summary>

    public sealed class SslTcpServer
    {
        public static void RunServer(IPAddress ipServer, int port)
        {
            TcpListener listener = null;
            try
            {
                listener = new TcpListener(ipServer, port);
                listener.Start();
                while (true)
                {
                    Console.WriteLine("Waiting for a client to connect...");
                    Logger.Write("Waiting for a client to connect...");

                    // Ожидаем нового подключения клиента
                    var client = listener.AcceptTcpClient();
                    // Отправляем подключенного клиента в отдельный поток
                    (new Thread(new ThreadStart((new ClientObject(client)).Process))).Start();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Logger.Write(ex.Message);
            }
            finally
            {
                if (listener != null)
                {
                    listener.Stop();
                }
            }
        }
    }
}