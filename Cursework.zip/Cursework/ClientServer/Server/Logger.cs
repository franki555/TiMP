﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Server
{
    /// <summary>
    /// Класс для работы с логами
    /// За основу взят паттерн Producer/Consumer
    /// Из нескольких потоков добавляются логи в оперативную память
    /// И в единственном потоке производится запись логов в файл
    /// И отчистка логов из оперативной памяти
    /// </summary>

    public static class Logger
    {
        private static List<string> logs = new List<string>();

        public static async void Process()
        {
            while (true)
            {
                while (logs.Count > 0)  // Если есть логи для записи
                {
                    // Записываем 1 элемент, так как он был добавлен первее
                    using (StreamWriter writer = new StreamWriter(FilePaths.path_logs, true))
                    {
                        await writer.WriteLineAsync(logs[0]);
                    }
                    logs.RemoveAt(0);   // Удаляем 1 элемент
                }
            }
        }

        public static void Write(string text)   // Запись логов в оперативную память
        {
            DateTime timeUTC = DateTime.UtcNow;
            logs.Add($"{timeUTC} {text}");
        }
    }
}