﻿using System.Net;
using System.Threading;

namespace Server
{
    class Program
    {
        private const int Port = 7777;

        static void Main(string[] args)
        {
            // Отдельный поток для записи логов в текстовый файл
            (new Thread(new ThreadStart(Logger.Process))).Start();

            // Запуск сервера
            // IPAddress.Any указывает
            // Что действия клиента должны контроллироваться
            // На всех сетевых интерфейсах
            SslTcpServer.RunServer(IPAddress.Any, Port);
        }
    }
}