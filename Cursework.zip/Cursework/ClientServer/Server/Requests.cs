﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace Server
{
    /// <summary>
    /// Модуль с запросами в базу данных
    /// </summary>

    public static class Request
    {
        public static async Task<string> Login(List<string> data)
        {
            string login = data[0];
            string password = data[1];
            string authKey = AuthentificationKey.GetAuthKey();

            if (CheckStringForChar.CheckForSQLInjection(login))
            {
                return "-1";
            }
            if (login.Length < 6 || login.Length > 16 ||
                password.Length < 6 || password.Length > 16)
            {
                return "-5";
            }

            password = MySHA256.Hash(password);

            DataBase db = new DataBase("Salon");
            await db.openConnectionAsync();

            string id_user = "";
            string bal = "";

            using (SqlCommand command = new SqlCommand(
                "SELECT Id_users FROM Users WHERE Login=@Login AND Password=@Password",
                db.getConnection()))
            {
                command.Parameters.AddWithValue("Login", login);
                command.Parameters.AddWithValue("Password", password);
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    await reader.ReadAsync();
                    if (reader.HasRows)
                    {
                        id_user = reader[0].ToString();
                    }
                    else
                    {
                        id_user = "0";
                    }
                }

                if (id_user != "0")
                {
                    command.CommandText = "SELECT Balance FROM Client WHERE Id_users=@Id_users";
                    command.Parameters.AddWithValue("Id_users", id_user);
                    using (SqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        await reader.ReadAsync();
                        if (reader.HasRows)
                        {
                            bal = reader[0].ToString();
                        }
                    }

                    command.CommandText = "UPDATE Users SET AuthKey=@AuthKey WHERE Id_users=@Id_users";
                    command.Parameters.AddWithValue("AuthKey", authKey);
                    if (await command.ExecuteNonQueryAsync() == 0)
                    {
                        await db.closeConnectionAsync();
                        return "0";
                    }
                }
            }

            string response;
            if (id_user == "0" || bal == "")
            {
                response = "0";
            }
            else
            {
                response = $"{id_user} {authKey} {bal}";
            }

            await db.closeConnectionAsync();
            return response;
        }

        public static async Task<string> Register(List<string> data)
        {
            string login = data[0];
            string password = data[1];
            string confirm = data[2];
            string username = data[3];
            string telegram = data[4];

            if (password != confirm)
            {
                return "0";
            }

            if (CheckStringForChar.CheckForSQLInjection(login) ||
                CheckStringForChar.CheckForSQLInjection(username) ||
                CheckStringForChar.CheckForSQLInjection(telegram))
            {
                return "-1";
            }
            if (login.Length < 6 || login.Length > 16 ||
                password.Length < 6 || password.Length > 16 ||
                username.Length < 6 || username.Length > 16)
            {
                return "-5";
            }

            password = MySHA256.Hash(password);

            DataBase db = new DataBase("Salon");
            await db.openConnectionAsync();

            string response;
            using (SqlCommand command = new SqlCommand(
                "INSERT INTO Users (Login, Password) VALUES (@Login, @Password)",
                db.getConnection()))
            {
                command.Parameters.AddWithValue("Login", login);
                command.Parameters.AddWithValue("Password", password);
                try
                {
                    await command.ExecuteNonQueryAsync();
                }
                catch (Exception e)
                {
                    Console.WriteLine($"Exception Request Register: {e.Message}");
                    Logger.Write($"Exception Request Register: {e.Message}");
                    await db.closeConnectionAsync();
                    return "0";
                }

                string id_users;
                command.CommandText =
                    "SELECT Id_users FROM Users WHERE Login=@Login";
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    await reader.ReadAsync();
                    if (reader.HasRows)
                    {
                        id_users = reader[0].ToString();
                    }
                    else
                    {
                        await db.closeConnectionAsync();
                        return "0";
                    }
                }

                command.CommandText =
                    "INSERT INTO Client (Id_users, Username, Telegram, Balance)" +
                    " VALUES (@Id_users, @Username, @Telegram, @Balance)";
                command.Parameters.AddWithValue("Id_users", id_users);
                command.Parameters.AddWithValue("Username", username);
                command.Parameters.AddWithValue("Telegram", telegram);
                command.Parameters.AddWithValue("Balance", 0);
                try
                {
                    await command.ExecuteNonQueryAsync();
                    response = "1";
                }
                catch (Exception e)
                {
                    Console.WriteLine($"Exception Request Register: {e.Message}");
                    Logger.Write($"Exception Request Register: {e.Message}");
                    command.CommandText = "DELETE FROM Users WHERE Id_users=@Id_users";
                    await command.ExecuteNonQueryAsync();
                    response = "0";
                }
            }
            await db.closeConnectionAsync();
            return response;
        }

        public static async Task<string> AddBalance(List<string> data)
        {
            string id_user = data[0];
            string authKey = data[1];
            string bal = data[2];
            string card = data[3];

            {
                string isAuth = await Authentification(id_user, authKey);
                if (isAuth != "1")
                    return isAuth;
            }

            if (CheckStringForChar.CheckForSQLInjection(id_user) ||
                CheckStringForChar.CheckForSQLInjection(bal) ||
                CheckStringForChar.CheckForSQLInjection(card))
            {
                return "-1";
            }
            if (!(isInt(id_user) || isInt(bal) || isInt(card)))
            {
                return "0";
            }
            if (Convert.ToInt32(id_user) <= 0 ||
                Convert.ToInt32(bal) <= 0 ||
                card.Length != 16)
            {
                return "0";
            }

            DataBase db = new DataBase("Salon");
            await db.openConnectionAsync();

            string response;
            using (SqlCommand command = new SqlCommand(
                "UPDATE Client SET Balance=((SELECT Balance FROM Client WHERE Id_users=@Id_users)+@Bal)" +
                " WHERE Id_users=@Id_users",
                db.getConnection()))
            {
                command.Parameters.AddWithValue("Id_users", id_user);
                command.Parameters.AddWithValue("Bal", bal);
                if (await command.ExecuteNonQueryAsync() > 0)
                {
                    response = "1";
                }
                else
                {
                    response = "0";
                }
            }
            await db.closeConnectionAsync();
            return response;
        }

        public static async Task<string> GetProduct(List<string> data)
        {
            string id_product = data[0];

            if (CheckStringForChar.CheckForSQLInjection(id_product))
            {
                return "-1";
            }
            if (!isInt(id_product))
            {
                return "0";
            }
            if (Convert.ToInt32(id_product) < 0)
            {
                return "0";
            }

            DataBase db = new DataBase("Salon");
            await db.openConnectionAsync();

            string response;
            using (SqlCommand command = new SqlCommand(
                "SELECT * FROM Product WHERE Id_product=" +
                "(SELECT MIN(Id_product) FROM Product WHERE Id_product>@Id_product)",
                db.getConnection()))
            {
                command.Parameters.AddWithValue("Id_product", id_product);
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    await reader.ReadAsync();
                    if (reader.HasRows)
                    {
                        string id = reader[0].ToString();
                        string name = reader[1].ToString();
                        string price = reader[2].ToString();
                        string quantity = reader[3].ToString();
                        response = $"{id} {name} {price} {quantity}";
                    }
                    else
                    {
                        response = "0";
                    }
                }
            }

            await db.closeConnectionAsync();
            return response;
        }

        public static async Task<string> GetImage(List<string> data)
        {
            string id_product = data[0];

            if (CheckStringForChar.CheckForSQLInjection(id_product))
            {
                return "-1";
            }
            if (!isInt(id_product))
            {
                return "0";
            }
            if (Convert.ToInt32(id_product) <= 0)
            {
                return "0";
            }

            DataBase db = new DataBase("Salon");
            await db.openConnectionAsync();

            string response;
            using (SqlCommand command = new SqlCommand(
               "SELECT Image FROM Product WHERE Id_product=@Id_product",
               db.getConnection()))
            {
                command.Parameters.AddWithValue("Id_product", id_product);
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    await reader.ReadAsync();
                    if (reader.HasRows)
                    {
                        byte[] image = (byte[])reader[0];
                        response = Convert.ToBase64String(image);
                    }
                    else
                    {
                        response = "0";
                    }
                }
            }
            await db.closeConnectionAsync();
            return response;
        }

        public static async Task<string> AddCart(List<string> data)
        {
            string id_user = data[0];
            string authKey = data[1];
            string id_product = data[2];
            string id_client = await GetIdClientFromIdUser(id_user);

            {
                string isAuth = await Authentification(id_user, authKey);
                if (isAuth != "1")
                {
                    return isAuth;
                }
            }

            if (id_client == "-1" || id_client == "0")
            {
                return id_client;
            }
            if (CheckStringForChar.CheckForSQLInjection(id_user) ||
                CheckStringForChar.CheckForSQLInjection(id_client) ||
                CheckStringForChar.CheckForSQLInjection(id_product))
            {
                return "-1";
            }
            if (!isInt(id_user) || !isInt(id_client) || !isInt(id_product))
            {
                return "0";
            }
            if (Convert.ToInt32(id_user) <= 0 ||
            Convert.ToInt32(id_client) <= 0 ||
            Convert.ToInt32(id_product) < 0)
            {
                return "0";
            }

            DataBase db = new DataBase("Salon");
            await db.openConnectionAsync();

            using (SqlCommand command = new SqlCommand(
                    "SELECT * FROM Cart WHERE Id_client=@Id_client AND Id_product=@Id_product",
                db.getConnection()))
            {
                command.Parameters.AddWithValue("Id_client", id_client);
                command.Parameters.AddWithValue("Id_product", id_product);
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    await reader.ReadAsync();
                    if (reader.HasRows)
                    {
                        await db.closeConnectionAsync();
                        return "-2";
                    }
                }

                command.CommandText =
                    "INSERT INTO Cart (Id_client, Id_product)" +
                    " VALUES (@Id_client, @Id_product)";
                try
                {
                    await command.ExecuteNonQueryAsync();
                }
                catch (Exception e)
                {
                    Console.WriteLine($"Exception Request AddCartr: {e.Message}");
                    Logger.Write($"Exception Request AddCart: {e.Message}");
                    await db.closeConnectionAsync();
                    return "0";
                }
            }

            await db.closeConnectionAsync();
            return "1";
        }

        public static async Task<string> DelCart(List<string> data)
        {
            string id_user = data[0];
            string authKey = data[1];
            string id_product = data[2];
            string id_client = await GetIdClientFromIdUser(id_user);

            {
                string isAuth = await Authentification(id_user, authKey);
                if (isAuth != "1")
                {
                    return isAuth;
                }
            }

            if (id_client == "-1" || id_client == "0")
            {
                return id_client;
            }
            if (CheckStringForChar.CheckForSQLInjection(id_user) ||
                CheckStringForChar.CheckForSQLInjection(id_client) ||
                CheckStringForChar.CheckForSQLInjection(id_product))
            {
                return "-1";
            }
            if (!isInt(id_user) || !isInt(id_client) || !isInt(id_product))
            {
                return "0";
            }
            if (Convert.ToInt32(id_user) <= 0 ||
                Convert.ToInt32(id_client) <= 0 ||
                Convert.ToInt32(id_product) <= 0)
            {
                return "0";
            }

            DataBase db = new DataBase("Salon");
            await db.openConnectionAsync();

            string response;
            using (SqlCommand command = new SqlCommand(
                "DELETE FROM Cart WHERE Id_client=@Id_client AND Id_product=@Id_product",
                db.getConnection()))
            {
                command.Parameters.AddWithValue("Id_client", id_client);
                command.Parameters.AddWithValue("Id_product", id_product);
                try
                {
                    await command.ExecuteNonQueryAsync();
                    response = "1";
                }
                catch (Exception e)
                {
                    Console.WriteLine($"Exception Request DelCart: {e.Message}");
                    Logger.Write($"Exception Request DelCart: {e.Message}");
                    response = "0";
                }
            }
            await db.closeConnectionAsync();
            return response;
        }

        public static async Task<string> GetCart(List<string> data)
        {
            string id_user = data[0];
            string authKey = data[1];
            string id_product = data[2];
            string id_client = await GetIdClientFromIdUser(id_user);

            {
                string isAuth = await Authentification(id_user, authKey);
                if (isAuth != "1")
                {
                    return isAuth;
                }
            }

            if (id_client == "-1" || id_client == "0")
            {
                return id_client;
            }
            if (CheckStringForChar.CheckForSQLInjection(id_user) ||
                CheckStringForChar.CheckForSQLInjection(id_product) ||
                CheckStringForChar.CheckForSQLInjection(id_client))
            {
                return "-1";
            }
            if (!isInt(id_user) || !isInt(id_product) || !isInt(id_client))
            {
                return "0";
            }
            if (Convert.ToInt32(id_user) <= 0 ||
                Convert.ToInt32(id_product) < 0 ||
                Convert.ToInt32(id_client) <= 0)
            {
                return "0";
            }

            DataBase db = new DataBase("Salon");
            await db.openConnectionAsync();

            using (SqlCommand command = new SqlCommand(
                    "SELECT * FROM Cart WHERE Id_client=@Id_client AND" +
                    " Id_product=(SELECT MIN(Id_product) FROM Cart WHERE Id_product>@Id_product" +
                    " AND Id_client=@Id_client)",
                db.getConnection()))
            {
                command.Parameters.AddWithValue("Id_product", id_product);
                command.Parameters.AddWithValue("Id_client", id_client);
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    await reader.ReadAsync();
                    if (reader.HasRows)
                    {
                        id_product = reader[2].ToString();
                    }
                    else
                    {
                        await db.closeConnectionAsync();
                        return "0";
                    }
                }
            }

            List<string> __id_product = new List<string>();
            __id_product.Add((Convert.ToInt32(id_product) - 1).ToString());
            List<string> productInformation = SplitString.Split(await GetProduct(__id_product));

            id_product = productInformation[0];
            string name = productInformation[1];
            string price = productInformation[2];
            string quantity = productInformation[3];

            string response = $"{id_product} {name} {price} {quantity}";
            return response;
        }

        public static async Task<string> BuyProduct(List<string> data)
        {
            string id_user = data[0];
            string authKey = data[1];
            string id_product = data[2];
            string count = data[3];
            string address_index = data[4];
            string __dateTime = data[5];
            string id_client = await GetIdClientFromIdUser(id_user);
            DateTime dateTime;

            {
                string isAuth = await Authentification(id_user, authKey);
                if (isAuth != "1")
                {
                    return isAuth;
                }
            }

            if (id_client == "-1" || id_client == "0")
            {
                return id_client;
            }
            if (CheckStringForChar.CheckForSQLInjection(id_user) ||
                CheckStringForChar.CheckForSQLInjection(id_product) ||
                CheckStringForChar.CheckForSQLInjection(count) ||
                CheckStringForChar.CheckForSQLInjection(address_index) ||
                CheckStringForChar.CheckForSQLInjection(__dateTime) ||
                CheckStringForChar.CheckForSQLInjection(id_client))
            {
                return "-1";
            }
            if (!isInt(id_user) || !isInt(id_client)||
                !isInt(id_product) || !isInt(count)||
                !isInt(address_index))
            {
                return "0";
            }
            if (Convert.ToInt32(id_user) <= 0 ||
                Convert.ToInt32(id_client) <= 0 ||
                Convert.ToInt32(id_product) <= 0 ||
                Convert.ToInt32(count) <= 0 ||
                address_index.Length != 6)
            {
                return "0";
            }
            try
            {
                dateTime = DateTime.Parse(__dateTime);
            }
            catch (Exception e)
            {
                Console.WriteLine($"Exception Request BuyProduct: {e.Message}");
                Logger.Write($"Exception Request BuyProduct: {e.Message}");
                return "0";
            }

            DataBase db = new DataBase("Salon");
            await db.openConnectionAsync();

            using (SqlCommand command = new SqlCommand(
                "SELECT Price, Quantity FROM Product WHERE Id_product=@Id_product",
                db.getConnection()))
            {
                command.Parameters.AddWithValue("Id_product", id_product);
                string price;
                string quantity;
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    await reader.ReadAsync();
                    if (reader.HasRows)
                    {
                        price = reader[0].ToString();
                        quantity = reader[1].ToString();
                    }
                    else
                    {
                        await db.closeConnectionAsync();
                        return "0";
                    }
                }

                if (Convert.ToInt32(quantity) < Convert.ToInt32(count))
                {
                    return "-3";
                }

                int total_price = Convert.ToInt32(count) * Convert.ToInt32(price);

                command.CommandText = "SELECT Balance FROM Client WHERE Id_client=@Id_client";
                command.Parameters.AddWithValue("Id_client", id_client);
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    await reader.ReadAsync();
                    if (reader.HasRows)
                    {
                        string balance = reader[0].ToString();
                        if(Convert.ToInt32(balance) < total_price)
                        {
                            await db.closeConnectionAsync();
                            return "-4";
                        }
                    }
                    else
                    {
                        await db.closeConnectionAsync();
                        return "0";
                    }
                }

                command.CommandText = 
                    "INSERT INTO [Order] (Id_client, Id_product, Count, Address_index, Delivery_date)" +
                    " VALUES (@Id_client, @Id_product, @Count, @Address_index, @Delivery_date)";
                command.Parameters.AddWithValue("Count", count);
                command.Parameters.AddWithValue("Address_index", address_index);
                command.Parameters.AddWithValue("Delivery_date", dateTime);
                try
                {
                    await command.ExecuteNonQueryAsync();
                }
                catch(Exception e)
                {
                    Console.WriteLine($"Exception Request BuyProduct: {e.Message}");
                    Logger.Write($"Exception Request BuyProduct: {e.Message}");
                    await db.closeConnectionAsync();
                    return "0";
                }

                command.CommandText =
                    "SELECT MAX(Id_order) FROM [Order] WHERE Id_client=@Id_client AND Id_product=@Id_product " +
                    "AND Count=@Count AND Address_index=@Address_index AND Delivery_date=@Delivery_date";
                string id_order;
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    await reader.ReadAsync();
                    if (reader.HasRows)
                    {
                        id_order = reader[0].ToString();
                    }
                    else
                    {
                        await db.closeConnectionAsync();
                        return "0";
                    }
                }

                command.CommandText =
                        "UPDATE Product SET Quantity=@Quantity WHERE Id_product=@Id_product";
                command.Parameters.AddWithValue("Quantity", Convert.ToInt32(quantity) - Convert.ToInt32(count));
                if (await command.ExecuteNonQueryAsync() != 1)
                {
                    command.CommandText = "DELETE FROM Order WHERE Id_order=@Id_order";
                    command.Parameters.AddWithValue("Id_order", id_order);
                }

                command.CommandText = "UPDATE Client SET Balance=((SELECT Balance FROM Client WHERE" +
                    " Id_client=@Id_client)-@Total_price) WHERE Id_client=@Id_client";
                command.Parameters.AddWithValue("Total_price", total_price);
                await command.ExecuteNonQueryAsync();

                return id_order;
            }
        }

        public static async Task<string> GetOrder(List<string> data)
        {
            string id_user = data[0];
            string authKey = data[1];
            string id_order = data[2];
            string id_client = await GetIdClientFromIdUser(id_user);

            {
                string isAuth = await Authentification(id_user, authKey);
                if (isAuth != "1")
                    return isAuth;
            }

            if (id_client == "-1" || id_client == "0")
            {
                return id_client;
            }
            if (CheckStringForChar.CheckForSQLInjection(id_client) ||
                CheckStringForChar.CheckForSQLInjection(id_order) ||
                CheckStringForChar.CheckForSQLInjection(id_client))
            {
                return "-1";
            }
            if (!isInt(id_client) || !isInt(id_order))
            {
                return "0";
            }
            if (Convert.ToInt32(id_client) <= 0 ||
                Convert.ToInt32(id_order) < 0 ||
                Convert.ToInt32(id_user) <= 0)
            {
                return "0";
            }

            DataBase db = new DataBase("Salon");
            await db.openConnectionAsync();

            string response;
            using (SqlCommand command = new SqlCommand(
                "SELECT * FROM [Order] WHERE Id_Order=" +
                "(SELECT MIN(Id_Order) FROM [Order] WHERE Id_order>@Id_order AND Id_client=@Id_client)" +
                "AND Id_client=@Id_client",
                db.getConnection()))
            {
                command.Parameters.AddWithValue("Id_order", id_order);
                command.Parameters.AddWithValue("Id_client", id_client);
                string id_product;
                string count;
                string address_index;
                string delivery_date;
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    await reader.ReadAsync();
                    if (reader.HasRows)
                    {
                        id_order = reader[0].ToString();
                        id_product = reader[2].ToString();
                        count = reader[3].ToString();
                        address_index = reader[4].ToString();
                        delivery_date = SplitString.Split(reader[5].ToString())[0];
                    }
                    else
                    {
                        return "0";
                    }
                }

                command.CommandText = "SELECT * FROM Product WHERE Id_product=@Id_product";
                command.Parameters.AddWithValue("Id_product", id_product);
                string name;
                string price;
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    await reader.ReadAsync();
                    if (reader.HasRows)
                    {
                        name = reader[1].ToString();
                        price = reader[2].ToString();
                    }
                    else
                    {
                        return "0";
                    }
                }
                price = (Convert.ToInt32(price) * Convert.ToInt32(count)).ToString();

                response = $"{id_order} {id_product} {name} {price}" +
                    $" {count} {address_index} {delivery_date}";
            }

            await db.closeConnectionAsync();
            return response;
        }

        public static async Task<string> ChangePswd(List<string> data)
        {
            string id_user = data[0];
            string authKey = data[1];
            string new_password = MySHA256.Hash(data[2]);
            string old_password = MySHA256.Hash(data[3]);

            {
                string isAuth = await Authentification(id_user, authKey);
                if (isAuth != "1")
                {
                    return isAuth;
                }
            }

            if (CheckStringForChar.CheckForSQLInjection(id_user) ||
                CheckStringForChar.CheckForSQLInjection(new_password) ||
                CheckStringForChar.CheckForSQLInjection(old_password))
            {
                return "-1";
            }
            if (!isInt(id_user))
            {
                return "0";
            }
            /*if (Convert.ToInt32(id_user) <= 0 ||
                new_password.Length < 6 || new_password.Length > 16 ||
                old_password.Length <6 || old_password.Length > 16)
            {
                return "0";
            }*/

            DataBase db = new DataBase("Salon");
            await db.openConnectionAsync();

            string response;
            using (SqlCommand command = new SqlCommand("UPDATE Users SET Password=@New_password WHERE " +
                    "Id_users=@Id_users AND Password=@Old_password",
                db.getConnection()))
            {
                command.Parameters.AddWithValue("Id_users", id_user);
                command.Parameters.AddWithValue("Old_password", old_password);
                command.Parameters.AddWithValue("New_password", new_password);
                if (await command.ExecuteNonQueryAsync() == 0)
                {
                    response = "0";
                }
                else
                {
                    response = "1";
                }
            }

            await db.closeConnectionAsync();
            return response;
        }

        public static async Task<string> GetAuthKey(List<string> data)
        {
            string id_user = data[0];
            string authKey = data[1];
            string newAuthKey = AuthentificationKey.GetAuthKey();

            if (CheckStringForChar.CheckForSQLInjection(id_user) ||
                CheckStringForChar.CheckForSQLInjection(authKey))
            {
                return "-1";
            }
            if (!isInt(id_user))
            {
                return "0";
            }
            if (Convert.ToInt32(id_user) <= 0)
            {
                return "0";
            }

            DataBase db = new DataBase("Salon");
            await db.openConnectionAsync();

            string response;
            using (SqlCommand command = new SqlCommand(
                "UPDATE Users SET AuthKey=@NewAuthKey WHERE Id_users=@Id_users AND AuthKey=@AuthKey",
                db.getConnection()))
            {
                command.Parameters.AddWithValue("Id_users", id_user);
                command.Parameters.AddWithValue("AuthKey", authKey);
                command.Parameters.AddWithValue("NewAuthKey", newAuthKey);

                if (await command.ExecuteNonQueryAsync() == 0)
                {
                    response = "0";
                }
                else
                {
                    response = authKey;
                }
            }

            await db.closeConnectionAsync();
            return response;
        }


        private static async Task<string> GetIdClientFromIdUser(string id_user)
        {
            if (CheckStringForChar.CheckForSQLInjection(id_user))
            {
                return "-1";
            }
            if (!isInt(id_user))
            {
                return "0";
            }
            if (Convert.ToInt32(id_user) <= 0)
            {
                return "0";
            }

            DataBase db = new DataBase("Salon");
            await db.openConnectionAsync();

            string id_client;
            using (SqlCommand command = new SqlCommand(
                "SELECT Id_client FROM Client WHERE Id_users=@Id_users",
                db.getConnection()))
            {
                command.Parameters.AddWithValue("Id_users", id_user);
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    await reader.ReadAsync();
                    if (reader.HasRows)
                    {
                        id_client = reader[0].ToString();
                    }
                    else
                    {
                        id_client = "0";
                    }
                }
            }

            await db.closeConnectionAsync();
            return id_client;
        }

        private static async Task<string> Authentification(string id_user, string authKey)
        {
            if (CheckStringForChar.CheckForSQLInjection(id_user) ||
                CheckStringForChar.CheckForSQLInjection(authKey))
            {
                return "-1";
            }
            if (!isInt(id_user))
            {
                return "0";
            }
            if (Convert.ToInt32(id_user) <= 0)
            {
                return "0";
            }

            DataBase db = new DataBase("Salon");
            await db.openConnectionAsync();

            string isAuthentificated = "0";

            using (SqlCommand command = new SqlCommand(
                "SELECT * FROM Users WHERE Id_users=@Id_users AND AuthKey=@AuthKey",
                db.getConnection()))
            {
                command.Parameters.AddWithValue("Id_users", id_user);
                command.Parameters.AddWithValue("AuthKey", authKey);
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    await reader.ReadAsync();
                    if (reader.HasRows)
                    {
                        isAuthentificated = "1";
                    }
                    else
                    {
                        isAuthentificated = "0";
                    }
                }
            }

            await db.closeConnectionAsync();
            return isAuthentificated;
        }

        private static bool isInt(string str)
        {
            foreach (var sym in str)
            {
                if (!char.IsDigit(sym))
                {
                    return false;
                }
            }
            return true;
        }
    }
}