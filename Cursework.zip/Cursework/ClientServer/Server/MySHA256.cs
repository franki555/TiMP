﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace Server
{
    /// <summary>
    /// Модуль для преобразования строки в зашифрованую строку
    /// С использованием встроенного алгоритма Хэш-Суммы SHA256
    /// </summary>

    public static class MySHA256
    {
        public static string Hash(string text)
        {
            byte[] data = Encoding.Default.GetBytes(text);
            var result = new SHA256Managed().ComputeHash(data);
            return BitConverter.ToString(result).Replace("-", "").ToLower();
        }
    }
}