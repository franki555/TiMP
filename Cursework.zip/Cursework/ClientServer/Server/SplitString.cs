﻿using System.Collections.Generic;

namespace Server
{
    /// <summary>
    /// Модуль для разбиения строки на слова
    /// </summary>

    public static class SplitString
    {
        public static List<string> Split(string str)
        {
            List<string> res = new List<string>();
            string buffer = "";
            for (int i = 0; i < str.Length; i++)
            {
                if (str[i] == ' ')
                {
                    if (buffer != " ")
                    {
                        res.Add(buffer);
                    }
                    buffer = "";
                }
                else
                {
                    buffer += str[i];
                }
            }
            res.Add(buffer);
            return res;
        }
    }
}