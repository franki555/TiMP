﻿namespace Server
{
    /// <summary>
    /// Файловые пути к сертификату
    /// И к текстовому файлу логов
    /// </summary>

    public static class FilePaths
    {
        public const string path_certificate = @"C:\Southern Beauty\server.pfx";
        public const string pass_certificate = "password";

        public const string path_logs = @"C:\Southern Beauty\logs.txt";
    }
}