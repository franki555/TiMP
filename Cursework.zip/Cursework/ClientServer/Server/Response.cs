﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Server
{
    /// <summary>
    /// Модуль, возвращающий response
    /// В зависимости от request
    /// </summary>

    public static class Response
    {
        // Разделяем строку на инструкцию
        // И на данные, которые отправил клиент
        public static async Task<string> Get(string request)
        {
            List<string> data = new List<string>();
            List<string> buff = SplitString.Split(request);
            string instruction = buff[0];
            for (int i = 1; i < buff.Count; i++)
            {
                data.Add(buff[i]);
            }
            return await GetResponse.Get(instruction, data);
        }

        // Обрабатываем инструкцию и данные клиента
        private static class GetResponse
        {
            public static async Task<string> Get(string instruction, List<string> data)
            {
                string response = "";
                switch (instruction)
                {
                    case "/login":
                        response = await Request.Login(data);
                        break;
                    case "/register":
                        response = await Request.Register(data);
                        break;
                    case "/addBalance":
                        response = await Request.AddBalance(data);
                        break;
                    case "/getProduct":
                        response = await Request.GetProduct(data);
                        break;
                    case "/getImage":
                        response = await Request.GetImage(data);
                        break;
                    case "/addCart":
                        response = await Request.AddCart(data);
                        break;
                    case "/delCart":
                        response = await Request.DelCart(data);
                        break;
                    case "/getCart":
                        response = await Request.GetCart(data);
                        break;
                    case "/buyProduct":
                        response = await Request.BuyProduct(data);
                        break;
                    case "/getOrder":
                        response = await Request.GetOrder(data);
                        break;
                    case "/changePswd":
                        response = await Request.ChangePswd(data);
                        break;
                    case "/getAuthKey":
                        response = await Request.GetAuthKey(data);
                        break;
                    default:
                        response = "0";
                        break;
                }
                return response;
            }
        }
    }
}