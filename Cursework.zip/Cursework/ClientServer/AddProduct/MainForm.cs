﻿using System;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AddProduct
{
    public partial class MainForm : Form
    {
        /// <summary>
        /// Variables
        /// </summary>

        private string imgLoc = "";

        /// <summary>
        /// Methods related to the form
        /// </summary>

        public MainForm()
        {
            InitializeComponent();
            SetStyle(ControlStyles.SupportsTransparentBackColor, true);
            label1.BackColor = Color.Transparent;
            label1.Font = new Font(label1.Font, label1.Font.Style | FontStyle.Bold);

            label2.BackColor = Color.Transparent;
            label2.Font = new Font(label1.Font, label1.Font.Style | FontStyle.Bold);

            label3.BackColor = Color.Transparent;
            label3.Font = new Font(label1.Font, label1.Font.Style | FontStyle.Bold);

            labelId.BackColor = Color.Transparent;
            labelId.Font = new Font(label1.Font, label1.Font.Style | FontStyle.Bold);
        }

        private void buttonLoad_Click(object sender, EventArgs e)
        {
            LoadImage();
        }

        private async void buttonAdd_Click(object sender, EventArgs e)
        {
            await AddProduct();
        }

        private async void buttonSearch_Click(object sender, EventArgs e)
        {
            await Search();
        }

        private async void buttonChange_Click(object sender, EventArgs e)
        {
            await Change();
        }

        private async void buttonDelete_Click(object sender, EventArgs e)
        {
            await DeleteProduct();
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void buttonPrintAll_Click(object sender, EventArgs e)
        {
            PrintAll();
        }

        /// <summary>
        /// Others methods
        /// </summary>

        private void LoadImage()
        {
            try
            {
                OpenFileDialog ofd = new OpenFileDialog();
                ofd.Filter = "Image Files (*.BMP; *.JPG; *.GIF; *.PNG)|*.BMP; *.JPG; *.GIF; *.PNG|All files(*.*)|*.*";
                ofd.Title = "Выберите фото продукта";

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    imgLoc = ofd.FileName.ToString();
                    pictureBoxImage.ImageLocation = imgLoc;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private async Task AddProduct()
        {
            string name_product = textBoxName.Text.ToString();
            if ((name_product.IndexOf(' ') > -1))
                name_product = name_product.Replace(" ", "|");
            if ((!string.IsNullOrEmpty(name_product) && !string.IsNullOrWhiteSpace(name_product))
                && (!string.IsNullOrEmpty(textBoxPrice.Text) && !string.IsNullOrWhiteSpace(textBoxPrice.Text))
                && (!string.IsNullOrEmpty(textBoxCount.Text) && !string.IsNullOrWhiteSpace(textBoxCount.Text))
                && (!string.IsNullOrEmpty(imgLoc) && !string.IsNullOrWhiteSpace(imgLoc)))
            {
                DataBase db = new DataBase("Salon");
                await db.openConnectionAsync();

                byte[] image = null;
                FileStream fileStream = new FileStream(imgLoc, FileMode.Open, FileAccess.Read);
                BinaryReader binaryReader = new BinaryReader(fileStream);

                image = binaryReader.ReadBytes((int)fileStream.Length);
                string price = textBoxPrice.Text.ToString();
                string quantity = textBoxCount.Text.ToString();

                SqlCommand command = new SqlCommand(
                    "INSERT INTO Product (Name, Price, Quantity, Image) VALUES (@Name, @Price, @Quantity, @Image)",
                    db.getConnection());
                command.Parameters.AddWithValue("Name", name_product);
                command.Parameters.AddWithValue("Price", price);
                command.Parameters.AddWithValue("Quantity", quantity);
                command.Parameters.AddWithValue("Image", image);

                try
                {
                    await command.ExecuteNonQueryAsync();
                    MessageBox.Show("Продукт успешно добавлен!");
                }
                catch
                {
                    MessageBox.Show("Продукт не был добавлен!");
                }

                await db.closeConnectionAsync();
            }
            else
            {
                MessageBox.Show("Все необходимые поля должны быть заполнены!");
            }
        }

        private async Task Search()
        {
            if (!string.IsNullOrEmpty(textBoxId.Text) && !string.IsNullOrWhiteSpace(textBoxId.Text))
            {
                DataBase db = new DataBase("Salon");
                await db.openConnectionAsync();

                string id_product = textBoxId.Text.ToString();
                string name_product = "";
                string price = "";
                string quantity = "";
                byte[] image = null;

                SqlCommand command = new SqlCommand(
                    "SELECT * FROM Product WHERE Id_product=@Id_product",
                    db.getConnection());
                command.Parameters.AddWithValue("Id_product", id_product);

                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    await reader.ReadAsync();
                    if (reader.HasRows)
                    {
                        name_product = reader[1].ToString();
                        price = reader[2].ToString();
                        quantity = reader[3].ToString();
                        image = (byte[])reader[4];
                    }
                }
                if (image != null)
                {
                    MemoryStream memoryStream = new MemoryStream(image);
                    pictureBoxImage.Image = Image.FromStream(memoryStream);
                }
                else
                {
                    pictureBoxImage.Image = null;
                }

                if ((name_product.IndexOf('|') > -1))
                {
                    name_product = name_product.Replace("|", " ");
                }

                textBoxId.Text = id_product;
                textBoxName.Text = name_product;
                textBoxPrice.Text = price;
                textBoxCount.Text = quantity;

                await db.closeConnectionAsync();
            }
            else
            {
                MessageBox.Show("Поле ID должно быть заполнено!");
            }
        }

        private async Task Change()
        {
            string name_product = textBoxName.Text.ToString();

            if ((name_product.IndexOf(' ') > -1))
            {
                name_product = name_product.Replace(" ", "|");
            }

            if ((!string.IsNullOrEmpty(textBoxId.Text) && !string.IsNullOrWhiteSpace(textBoxId.Text))
                || (!string.IsNullOrEmpty(name_product) && !string.IsNullOrWhiteSpace(name_product))
                || (!string.IsNullOrEmpty(textBoxPrice.Text) && !string.IsNullOrWhiteSpace(textBoxPrice.Text))
                || (!string.IsNullOrEmpty(textBoxCount.Text) && !string.IsNullOrWhiteSpace(textBoxCount.Text))
                || (!string.IsNullOrEmpty(imgLoc) && !string.IsNullOrWhiteSpace(imgLoc)))
            {
                DataBase db = new DataBase("Salon");
                await db.openConnectionAsync();

                byte[] image = null;
                if (imgLoc != "")
                {
                    FileStream fileStream = new FileStream(imgLoc, FileMode.Open, FileAccess.Read);
                    BinaryReader binaryReader = new BinaryReader(fileStream);
                    image = binaryReader.ReadBytes((int)fileStream.Length);
                }

                string id_product = textBoxId.Text.ToString();
                string price = textBoxPrice.Text.ToString();
                string quantity = textBoxCount.Text.ToString();

                SqlCommand command = new SqlCommand(
                    "UPDATE Product SET Name=@Name, Price=@Price, Quantity=@Quantity, Image=@Image " +
                    "WHERE Id_product=@Id_product",
                    db.getConnection());
                command.Parameters.AddWithValue("Id_product", id_product);
                command.Parameters.AddWithValue("Name", name_product);
                command.Parameters.AddWithValue("Price", price);
                command.Parameters.AddWithValue("Quantity", quantity);
                command.Parameters.AddWithValue("Image", image);

                try
                {
                    await command.ExecuteNonQueryAsync();
                    MessageBox.Show("Продукт успешно изменен!");
                }
                catch
                {
                    MessageBox.Show("Продукт не был изменен!");
                }

                await db.closeConnectionAsync();
            }
            else
            {
                MessageBox.Show("Все необходимые поля должны быть заполнены!");
            }
        }

        private async Task DeleteProduct()
        {
            if (!string.IsNullOrEmpty(textBoxId.Text) && !string.IsNullOrWhiteSpace(textBoxId.Text))
            {
                DataBase db = new DataBase("Salon");
                await db.openConnectionAsync();

                string id_product = textBoxId.Text.ToString();

                SqlCommand command = new SqlCommand(
                    "DELETE FROM Product WHERE Id_product=@Id_product",
                    db.getConnection());
                command.Parameters.AddWithValue("Id_product", id_product);

                if (await command.ExecuteNonQueryAsync() == 1)
                {
                    MessageBox.Show("Продукт успешно удален!");
                }
                else
                {
                    MessageBox.Show("Продукт не был удален!");
                }

                await db.closeConnectionAsync();
            }
            else
            {
                MessageBox.Show("Поле ID должно быть заполнено!");
            }
        }

        private void PrintAll()
        {
            AllProducts allProducts = new AllProducts();
            allProducts.Show();
        }
    }
}