﻿using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AddProduct
{
    public partial class AllProducts : Form
    {
        public AllProducts()
        {
            InitializeComponent();

            FillDataGrid();
        }

        private async void FillDataGrid()
        {
            DataBase db = new DataBase("Salon");
            await db.openConnectionAsync();

            SqlDataAdapter adapter = new SqlDataAdapter(
                "SELECT Id_product, Name, Price, Quantity FROM Product", db.getConnection());
            DataSet ds = new DataSet();

            adapter.Fill(ds);
            dataGridViewProducts.DataSource = ds.Tables[0];

            await db.closeConnectionAsync();
        }
    }
}
