﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace AddProduct
{
    /// <summary>
    /// Модуль для работы с базой данных
    /// Используются асинхронные методы
    /// </summary>

    interface IDataBase
    {
        Task openConnectionAsync();
        Task closeConnectionAsync();
        SqlConnection getConnection();
        bool status();
    }

    class DataBase : IDataBase
    {
        private SqlConnection sqlConnection = null;

        public DataBase(string connectStr)
        {
            sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings[connectStr].ConnectionString);
        }

        public async Task openConnectionAsync()
        {
            await sqlConnection.OpenAsync();
        }

        public async Task closeConnectionAsync()
        {
            if (status())
                await sqlConnection.CloseAsync();
        }

        public SqlConnection getConnection()
        {
            if (sqlConnection != null)
                return sqlConnection;
            else
                return null;
        }

        public bool status()
        {
            return sqlConnection.State == ConnectionState.Open ? true : false;
        }
    }
}